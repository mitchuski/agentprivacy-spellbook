"use strict";
(() => {
  // src/content/spring-physics.ts
  var SpringTether = class {
    x;
    y;
    vx = 0;
    vy = 0;
    stiffness;
    damping;
    constructor(initialX = 0, initialY = 0, config = { stiffness: 0.06, damping: 0.75 }) {
      this.x = initialX;
      this.y = initialY;
      this.stiffness = config.stiffness;
      this.damping = config.damping;
    }
    update(targetX, targetY) {
      const ax = (targetX - this.x) * this.stiffness;
      const ay = (targetY - this.y) * this.stiffness;
      this.vx = (this.vx + ax) * this.damping;
      this.vy = (this.vy + ay) * this.damping;
      this.x += this.vx;
      this.y += this.vy;
      return { x: this.x, y: this.y };
    }
    setPosition(x, y) {
      this.x = x;
      this.y = y;
      this.vx = 0;
      this.vy = 0;
    }
    getVelocity() {
      return { vx: this.vx, vy: this.vy };
    }
    getSpeed() {
      return Math.sqrt(this.vx * this.vx + this.vy * this.vy);
    }
  };
  var MouseTracker = class {
    x;
    y;
    constructor() {
      this.x = window.innerWidth / 2;
      this.y = window.innerHeight / 2;
      document.addEventListener("mousemove", (e) => {
        this.x = e.clientX;
        this.y = e.clientY;
      }, { passive: true });
    }
    getPosition() {
      return { x: this.x, y: this.y };
    }
  };

  // src/content/orb-renderer.ts
  var ORB_COLORS = {
    swordsman: {
      primary: "#534AB7",
      glow: "rgba(83, 74, 183, 0.3)",
      dark: "#AFA9EC"
    },
    mage: {
      primary: "#1D9E75",
      glow: "rgba(29, 158, 117, 0.3)",
      dark: "#5DCAA5"
    },
    convergence: "#EF9F27",
    drake: "#FFD700",
    constellation: {
      node: "rgba(239, 159, 39, 1)",
      nodeGlow: "rgba(239, 159, 39, 0.3)",
      edge: "rgba(239, 159, 39, 0.5)"
    }
  };
  var SWORDSMAN_RADIUS = 16;
  var MAGE_RADIUS = 16;
  var GLOW_MULTIPLIER = 2.5;
  var OrbRenderer = class {
    canvas;
    ctx;
    dpr;
    // Render state
    swordsmanPos = { x: 0, y: 0 };
    magePos = null;
    mageVisible = false;
    // Constellation state (from Mage)
    constellationNodes = [];
    constellationEdges = [];
    patterns = [];
    // Drake state
    drakeNodes = [];
    drakePatrolPath = [];
    drakeProgress = 0;
    // Animation params
    animParams = {
      orbitRadii: 1,
      spellSpawnRate: 0.5,
      phaseCoupling: 0.5,
      edgeThreshold: 180,
      glowIntensity: 0.3,
      gridVisibility: 0.05
    };
    // Gap indicator
    gapScore = 50;
    constructor() {
      this.canvas = this.createCanvas();
      this.ctx = this.canvas.getContext("2d");
      this.dpr = window.devicePixelRatio || 1;
      this.setupCanvas();
      this.setupResizeHandler();
    }
    createCanvas() {
      const canvas = document.createElement("canvas");
      canvas.id = "swordsman-overlay";
      canvas.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483646;
      pointer-events: none;
      background: transparent;
    `;
      document.documentElement.appendChild(canvas);
      return canvas;
    }
    setupCanvas() {
      const width = window.innerWidth;
      const height = window.innerHeight;
      this.canvas.width = width * this.dpr;
      this.canvas.height = height * this.dpr;
      this.canvas.style.width = `${width}px`;
      this.canvas.style.height = `${height}px`;
      this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    }
    setupResizeHandler() {
      window.addEventListener("resize", () => {
        this.setupCanvas();
      });
    }
    // ============================================
    // STATE UPDATES
    // ============================================
    setSwordsmanPosition(x, y) {
      this.swordsmanPos = { x, y };
    }
    setMagePosition(x, y) {
      this.magePos = { x, y };
      this.mageVisible = true;
    }
    setMageVisible(visible) {
      this.mageVisible = visible;
    }
    setConstellation(nodes, edges, patterns) {
      this.constellationNodes = nodes;
      this.constellationEdges = edges;
      this.patterns = patterns;
    }
    setDrakeFormation(nodes, patrolPath, progress) {
      this.drakeNodes = nodes;
      this.drakePatrolPath = patrolPath;
      this.drakeProgress = progress;
    }
    setAnimationParams(params) {
      this.animParams = params;
    }
    setGapScore(score) {
      this.gapScore = score;
    }
    // ============================================
    // RENDERING
    // ============================================
    render() {
      const width = window.innerWidth;
      const height = window.innerHeight;
      this.ctx.clearRect(0, 0, width, height);
      this.drawGrid(width, height);
      this.drawTether();
      this.drawConstellationEdges();
      this.drawConstellationNodes();
      if (this.drakeNodes.length > 0 && this.drakeProgress > 0) {
        this.drawDrake();
      }
      if (this.mageVisible && this.magePos) {
        this.drawGapIndicator();
      }
      if (this.mageVisible && this.magePos) {
        this.drawMageOrb();
      }
      this.drawSwordsmanOrb();
    }
    drawGrid(width, height) {
      const visibility = this.animParams.gridVisibility;
      if (visibility < 0.01) return;
      this.ctx.strokeStyle = `rgba(83, 74, 183, ${visibility})`;
      this.ctx.lineWidth = 0.5;
      const gridSize = 50;
      for (let x = 0; x < width; x += gridSize) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, 0);
        this.ctx.lineTo(x, height);
        this.ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        this.ctx.beginPath();
        this.ctx.moveTo(0, y);
        this.ctx.lineTo(width, y);
        this.ctx.stroke();
      }
    }
    drawTether() {
    }
    drawSwordsmanOrb() {
      const { x, y } = this.swordsmanPos;
      const glowRadius = SWORDSMAN_RADIUS * GLOW_MULTIPLIER;
      const gradient = this.ctx.createRadialGradient(x, y, 0, x, y, glowRadius);
      gradient.addColorStop(0, `rgba(83, 74, 183, ${this.animParams.glowIntensity})`);
      gradient.addColorStop(1, "rgba(83, 74, 183, 0)");
      this.ctx.beginPath();
      this.ctx.arc(x, y, glowRadius, 0, Math.PI * 2);
      this.ctx.fillStyle = gradient;
      this.ctx.fill();
      this.ctx.beginPath();
      this.ctx.arc(x, y, SWORDSMAN_RADIUS, 0, Math.PI * 2);
      this.ctx.fillStyle = ORB_COLORS.swordsman.primary;
      this.ctx.fill();
      this.ctx.beginPath();
      this.ctx.arc(x, y, SWORDSMAN_RADIUS - 2, 0, Math.PI * 2);
      this.ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
      this.ctx.lineWidth = 1;
      this.ctx.stroke();
      this.ctx.font = "bold 12px sans-serif";
      this.ctx.fillStyle = "white";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";
      this.ctx.fillText("\u2694", x, y);
    }
    drawMageOrb() {
      if (!this.magePos) return;
      const { x, y } = this.magePos;
      const glowRadius = MAGE_RADIUS * GLOW_MULTIPLIER;
      const gradient = this.ctx.createRadialGradient(x, y, 0, x, y, glowRadius);
      gradient.addColorStop(0, `rgba(29, 158, 117, ${this.animParams.glowIntensity})`);
      gradient.addColorStop(1, "rgba(29, 158, 117, 0)");
      this.ctx.beginPath();
      this.ctx.arc(x, y, glowRadius, 0, Math.PI * 2);
      this.ctx.fillStyle = gradient;
      this.ctx.fill();
      this.ctx.beginPath();
      this.ctx.arc(x, y, MAGE_RADIUS, 0, Math.PI * 2);
      this.ctx.fillStyle = ORB_COLORS.mage.primary;
      this.ctx.fill();
      this.ctx.beginPath();
      this.ctx.arc(x, y, MAGE_RADIUS - 2, 0, Math.PI * 2);
      this.ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
      this.ctx.lineWidth = 1;
      this.ctx.stroke();
      this.ctx.font = "bold 10px sans-serif";
      this.ctx.fillStyle = "white";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";
      this.ctx.fillText("\u2726", x, y);
    }
    drawConstellationEdges() {
      for (const edge of this.constellationEdges) {
        const fromNode = this.constellationNodes.find((n) => n.id === edge.from);
        const toNode = this.constellationNodes.find((n) => n.id === edge.to);
        if (!fromNode || !toNode) continue;
        this.ctx.beginPath();
        this.ctx.moveTo(fromNode.x, fromNode.y);
        this.ctx.lineTo(toNode.x, toNode.y);
        this.ctx.strokeStyle = `rgba(239, 159, 39, ${edge.strength * 0.5})`;
        this.ctx.lineWidth = edge.type === "solid" ? 1 : 0.5;
        if (edge.type === "dashed") {
          this.ctx.setLineDash([4, 4]);
        }
        this.ctx.stroke();
        this.ctx.setLineDash([]);
      }
    }
    drawConstellationNodes() {
      for (const node of this.constellationNodes) {
        const { x, y, opacity, yangYin, emoji } = node;
        this.ctx.beginPath();
        this.ctx.arc(x, y, 12, 0, Math.PI * 2);
        this.ctx.fillStyle = `rgba(239, 159, 39, ${opacity * 0.3})`;
        this.ctx.fill();
        this.ctx.beginPath();
        this.ctx.arc(x, y, 6, 0, Math.PI * 2);
        if (yangYin === "yang") {
          this.ctx.fillStyle = `rgba(239, 159, 39, ${opacity})`;
          this.ctx.fill();
        } else {
          this.ctx.strokeStyle = `rgba(239, 159, 39, ${opacity})`;
          this.ctx.lineWidth = 1.5;
          this.ctx.stroke();
        }
        if (emoji) {
          this.ctx.font = "10px sans-serif";
          this.ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
          this.ctx.textAlign = "center";
          this.ctx.textBaseline = "middle";
          this.ctx.fillText(emoji, x, y - 12);
        }
        if (node.pulse > 0) {
          this.ctx.beginPath();
          this.ctx.arc(x, y, 6 + node.pulse * 10, 0, Math.PI * 2);
          this.ctx.strokeStyle = `rgba(239, 159, 39, ${(1 - node.pulse) * 0.5})`;
          this.ctx.lineWidth = 1;
          this.ctx.stroke();
        }
      }
    }
    drawGapIndicator() {
      if (!this.magePos) return;
      const sx = this.swordsmanPos.x;
      const sy = this.swordsmanPos.y;
      const mx = this.magePos.x;
      const my = this.magePos.y;
      this.ctx.beginPath();
      this.ctx.moveTo(sx, sy);
      this.ctx.lineTo(mx, my);
      const t = this.gapScore / 100;
      const r = Math.round(239 * t + 29 * (1 - t));
      const g = Math.round(159 * (1 - t) + 158 * (1 - t));
      const b = Math.round(39 * (1 - t) + 117 * (1 - t));
      this.ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, 0.2)`;
      this.ctx.lineWidth = 1;
      this.ctx.setLineDash([4, 8]);
      this.ctx.stroke();
      this.ctx.setLineDash([]);
      const midX = (sx + mx) / 2;
      const midY = (sy + my) / 2;
      this.ctx.font = "10px monospace";
      this.ctx.fillStyle = `rgba(${r}, ${g}, ${b}, 0.5)`;
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";
      this.ctx.fillText(`${this.gapScore}`, midX, midY - 10);
    }
    drawDrake() {
      if (this.drakeNodes.length === 0) return;
      const progress = this.drakeProgress;
      this.ctx.beginPath();
      this.ctx.strokeStyle = `rgba(255, 215, 0, ${progress * 0.8})`;
      this.ctx.lineWidth = 3;
      for (let i = 0; i < this.drakeNodes.length; i++) {
        const node = this.drakeNodes[i];
        if (i === 0) {
          this.ctx.moveTo(node.position.x, node.position.y);
        } else {
          this.ctx.lineTo(node.position.x, node.position.y);
        }
      }
      this.ctx.stroke();
      for (const node of this.drakeNodes) {
        const { x, y } = node.position;
        this.ctx.beginPath();
        this.ctx.arc(x, y, 15 * progress, 0, Math.PI * 2);
        this.ctx.fillStyle = `rgba(255, 215, 0, ${progress * 0.3})`;
        this.ctx.fill();
        this.ctx.beginPath();
        this.ctx.arc(x, y, 8 * progress, 0, Math.PI * 2);
        this.ctx.fillStyle = `rgba(255, 215, 0, ${progress * node.health})`;
        this.ctx.fill();
        this.ctx.font = "8px monospace";
        this.ctx.fillStyle = `rgba(255, 255, 255, ${progress})`;
        this.ctx.textAlign = "center";
        this.ctx.textBaseline = "middle";
        this.ctx.fillText(node.pvmCondition, x, y);
      }
      if (this.drakePatrolPath.length > 1) {
        this.ctx.beginPath();
        this.ctx.setLineDash([2, 4]);
        this.ctx.strokeStyle = `rgba(255, 215, 0, ${progress * 0.2})`;
        this.ctx.lineWidth = 1;
        for (let i = 0; i < this.drakePatrolPath.length; i++) {
          const point = this.drakePatrolPath[i];
          if (i === 0) {
            this.ctx.moveTo(point.x, point.y);
          } else {
            this.ctx.lineTo(point.x, point.y);
          }
        }
        this.ctx.closePath();
        this.ctx.stroke();
        this.ctx.setLineDash([]);
      }
    }
    // ============================================
    // CLEANUP
    // ============================================
    destroy() {
      this.canvas.remove();
    }
  };

  // ../shared/types/repertoire.ts
  var REPERTOIRE_STORAGE_KEY = "agentprivacy_spell_repertoire";
  var SYNC_DOMAINS = ["agentprivacy.ai", "www.agentprivacy.ai"];
  function parseRepertoire(raw) {
    try {
      const data = JSON.parse(raw);
      if (data.version === "1.0") {
        return data;
      }
      if (data.learnedSpells && Array.isArray(data.learnedSpells)) {
        console.warn("[Repertoire] Unknown version, extracting basic data");
        return {
          version: "1.0",
          learnedSpells: data.learnedSpells,
          castHistory: data.castHistory || [],
          trainingProgress: data.trainingProgress || {
            sectionsVisited: [],
            orbConvergenceCount: 0,
            spellsCastCount: 0,
            drakeSpellUnlocked: false,
            pathUnlocked: false
          },
          lastUpdated: data.lastUpdated || Date.now()
        };
      }
      return null;
    } catch (e) {
      console.error("[Repertoire] Failed to parse:", e);
      return null;
    }
  }

  // ../shared/types/index.ts
  var MAGE_EXTENSION_ID = "MAGE_EXTENSION_ID_PLACEHOLDER";

  // src/content/ceremony-channel.ts
  var CeremonyChannel = class {
    magePresent = false;
    mageOrbPosition = { x: 0, y: 0 };
    callbacks;
    discoveryInterval = null;
    positionSendInterval = null;
    lastPositionSend = 0;
    // Current state to send
    currentOrbPosition = { x: 0, y: 0 };
    currentMyTermsState = {};
    currentHexagramState = { lines: [1, 0, 1, 0, 1, 0] };
    constructor(callbacks) {
      this.callbacks = callbacks;
      this.setupExternalMessageListener();
    }
    // ============================================
    // DISCOVERY
    // ============================================
    startDiscovery() {
      this.discoverMage();
      this.discoveryInterval = window.setInterval(() => {
        if (!this.magePresent) {
          this.discoverMage();
        }
      }, 3e4);
    }
    stopDiscovery() {
      if (this.discoveryInterval !== null) {
        clearInterval(this.discoveryInterval);
        this.discoveryInterval = null;
      }
    }
    discoverMage() {
      try {
        chrome.runtime.sendMessage(MAGE_EXTENSION_ID, {
          type: "SWORD_PRESENT",
          domain: location.hostname,
          myTermsState: this.currentMyTermsState,
          orbPosition: this.currentOrbPosition,
          bladeLevel: 1,
          hexagramState: this.currentHexagramState
        }, (response) => {
          if (chrome.runtime.lastError) {
            if (this.magePresent) {
              this.magePresent = false;
              this.callbacks.onMageDisconnected();
            }
            return;
          }
          if (response?.type === "MAGE_ACKNOWLEDGE") {
            if (!this.magePresent) {
              this.magePresent = true;
              this.mageOrbPosition = response.orbPosition || { x: 100, y: 100 };
              this.callbacks.onMageDetected(this.mageOrbPosition, response.spellbookState || []);
              this.startPositionSync();
            }
          }
        });
      } catch {
        if (this.magePresent) {
          this.magePresent = false;
          this.callbacks.onMageDisconnected();
        }
      }
    }
    // ============================================
    // MESSAGE LISTENER
    // ============================================
    setupExternalMessageListener() {
      chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
        if (sender.id !== MAGE_EXTENSION_ID) return;
        this.handleMageMessage(message, sendResponse);
        return true;
      });
    }
    handleMageMessage(message, sendResponse) {
      switch (message.type) {
        case "MAGE_PRESENT":
          this.magePresent = true;
          this.mageOrbPosition = message.orbPosition;
          sendResponse({
            type: "SWORD_ACKNOWLEDGE",
            orbPosition: this.currentOrbPosition,
            myTermsState: this.currentMyTermsState
          });
          this.callbacks.onMageDetected(message.orbPosition, message.spellbookState);
          this.startPositionSync();
          break;
        case "MAGE_ORB_POSITION":
          this.mageOrbPosition = { x: message.x, y: message.y };
          this.callbacks.onMageOrbPosition(message.x, message.y);
          sendResponse({ acknowledged: true });
          break;
        case "CONSTELLATION_UPDATE":
          this.callbacks.onConstellationUpdate(message.nodes, message.edges, message.patterns);
          sendResponse({ acknowledged: true });
          break;
        case "CONSTELLATION_WAVE":
          this.callbacks.onConstellationWave(message.payload, message.animation);
          sendResponse({ acknowledged: true });
          break;
        case "SCAN_RESULTS":
          this.callbacks.onScanResults(message.findings);
          sendResponse({ acknowledged: true });
          break;
        case "HEXAGRAM_UPDATE":
          this.callbacks.onHexagramUpdate(message.state, message.animationParams);
          sendResponse({ acknowledged: true });
          break;
        case "DRAKE_FORMATION":
          this.callbacks.onDrakeFormation(message.bodyNodes, message.patrolPath, message.formationProgress);
          sendResponse({ acknowledged: true });
          break;
        case "CEREMONY_BEGIN":
          this.callbacks.onCeremonyBegin(message.ceremonyType, message.initiator);
          sendResponse({ acknowledged: true });
          break;
        case "SPELL_CAST":
          this.callbacks.onSpellCast(message.spell);
          sendResponse({ acknowledged: true });
          break;
        default:
          sendResponse({ error: "Unknown message type" });
      }
    }
    // ============================================
    // POSITION SYNC
    // ============================================
    startPositionSync() {
      this.positionSendInterval = window.setInterval(() => {
        this.maybeSendPosition();
      }, 33);
    }
    stopPositionSync() {
      if (this.positionSendInterval !== null) {
        clearInterval(this.positionSendInterval);
        this.positionSendInterval = null;
      }
    }
    maybeSendPosition() {
      if (!this.magePresent) return;
      const now = performance.now();
      if (now - this.lastPositionSend < 33) return;
      this.lastPositionSend = now;
      this.sendToMage({
        type: "ORB_POSITION",
        x: this.currentOrbPosition.x,
        y: this.currentOrbPosition.y
      });
    }
    updateOrbPosition(x, y) {
      this.currentOrbPosition = { x, y };
    }
    // ============================================
    // SEND MESSAGES
    // ============================================
    sendToMage(message) {
      if (!this.magePresent) return;
      try {
        chrome.runtime.sendMessage(MAGE_EXTENSION_ID, message);
      } catch (error) {
        console.error("[Swordsman] Failed to send to Mage:", error);
      }
    }
    sendSlash(target, assertion, intensity = 5) {
      this.sendToMage({
        type: "SLASH",
        target,
        domain: location.hostname,
        assertion,
        intensity
      });
    }
    sendWard(boundary, terms, hexagramLine, yangState) {
      this.sendToMage({
        type: "WARD",
        boundary,
        terms,
        hexagramLine,
        yangState
      });
    }
    sendTermAssert(assertions, constellationHash) {
      this.sendToMage({
        type: "TERM_ASSERT",
        domain: location.hostname,
        assertions,
        constellationHash,
        hexagram: this.currentHexagramState
      });
    }
    sendCeremonyBegin(ceremonyType) {
      this.sendToMage({
        type: "CEREMONY_BEGIN",
        ceremonyType,
        initiator: "SWORD",
        conditions: {
          orbDistance: this.getOrbDistance(),
          spellsCast: 0,
          // TODO: Track
          gapScore: 50,
          // TODO: Track
          drakeEligible: false
          // TODO: Track
        }
      });
    }
    sendSummonDrake(conditions) {
      this.sendToMage({
        type: "SUMMON_DRAKE",
        conditions
      });
    }
    // ============================================
    // STATE
    // ============================================
    isMagePresent() {
      return this.magePresent;
    }
    getMageOrbPosition() {
      return this.mageOrbPosition;
    }
    getOrbDistance() {
      const dx = this.currentOrbPosition.x - this.mageOrbPosition.x;
      const dy = this.currentOrbPosition.y - this.mageOrbPosition.y;
      return Math.sqrt(dx * dx + dy * dy);
    }
    setMyTermsState(state2) {
      this.currentMyTermsState = state2;
    }
    setHexagramState(state2) {
      this.currentHexagramState = state2;
    }
    // ============================================
    // CLEANUP
    // ============================================
    destroy() {
      this.stopDiscovery();
      this.stopPositionSync();
    }
  };

  // src/content/page-analyzer.ts
  var TRACKER_CATEGORIES = {
    "google-analytics.com": "analytics",
    "googletagmanager.com": "tag-management",
    "facebook.net": "social",
    "facebook.com": "social",
    "doubleclick.net": "advertising",
    "googlesyndication.com": "advertising",
    "hotjar.com": "session-recording",
    "fullstory.com": "session-recording",
    "clarity.ms": "session-recording",
    "mixpanel.com": "analytics",
    "segment.com": "data-collection",
    "segment.io": "data-collection",
    "amplitude.com": "analytics",
    "heap.io": "analytics",
    "newrelic.com": "analytics",
    "sentry.io": "analytics",
    "intercom.io": "analytics",
    "hubspot.com": "analytics",
    "twitter.com": "social",
    "linkedin.com": "social",
    "pinterest.com": "social",
    "tiktok.com": "social",
    "snap.com": "social",
    "bing.com": "advertising",
    "criteo.com": "advertising",
    "outbrain.com": "advertising",
    "taboola.com": "advertising"
  };
  var BANNER_SELECTORS = [
    "#onetrust-banner-sdk",
    "#onetrust-consent-sdk",
    ".cookieconsent",
    "#cookie-banner",
    "#cookie-notice",
    "#cookie-law-info-bar",
    '[class*="cookie-banner"]',
    '[class*="cookie-consent"]',
    '[class*="cookiebanner"]',
    '[id*="cookie-banner"]',
    '[id*="cookie-consent"]',
    '[class*="gdpr"]',
    '[id*="gdpr"]',
    '[class*="consent-banner"]',
    '[id*="consent-banner"]',
    ".cc-banner",
    "#CybotCookiebotDialog"
  ];
  var REJECT_PATTERNS = /reject|decline|refuse|deny|no\s*thanks|essential\s*only|necessary\s*only|manage|customize|settings/i;
  function analyzePage() {
    const domain = location.hostname;
    const url = location.href;
    const timestamp = Date.now();
    const trackers = findTrackers(domain);
    const cookieBanner = detectCookieBanner();
    const forms = analyzeForms();
    const privacyPolicyLink = findPrivacyPolicyLink();
    const gapScore = calculateGapScore(trackers, cookieBanner, forms);
    return {
      domain,
      url,
      timestamp,
      trackers,
      cookieBanner,
      forms,
      privacyPolicyLink,
      gapScore
    };
  }
  function findTrackers(currentDomain) {
    const trackers = [];
    const seen = /* @__PURE__ */ new Set();
    for (const script of document.scripts) {
      if (!script.src) continue;
      try {
        const url = new URL(script.src);
        const hostname = url.hostname;
        if (hostname === currentDomain || hostname.endsWith("." + currentDomain)) continue;
        if (seen.has(hostname)) continue;
        seen.add(hostname);
        const category = categorizeTracker(hostname);
        trackers.push({ hostname, category });
      } catch {
      }
    }
    for (const iframe of document.querySelectorAll("iframe")) {
      const src = iframe.src;
      if (!src) continue;
      try {
        const url = new URL(src);
        const hostname = url.hostname;
        if (hostname === currentDomain || hostname.endsWith("." + currentDomain)) continue;
        if (seen.has(hostname)) continue;
        seen.add(hostname);
        const category = categorizeTracker(hostname);
        trackers.push({ hostname, category });
      } catch {
      }
    }
    for (const img of document.querySelectorAll("img")) {
      const src = img.src;
      if (!src) continue;
      try {
        const url = new URL(src);
        const hostname = url.hostname;
        if (hostname === currentDomain || hostname.endsWith("." + currentDomain)) continue;
        if (seen.has(hostname)) continue;
        const category = categorizeTracker(hostname);
        if (category !== "unknown") {
          seen.add(hostname);
          trackers.push({ hostname, category });
        }
      } catch {
      }
    }
    return trackers;
  }
  function categorizeTracker(hostname) {
    for (const [pattern, category] of Object.entries(TRACKER_CATEGORIES)) {
      if (hostname === pattern || hostname.endsWith("." + pattern)) {
        return category;
      }
    }
    return "unknown";
  }
  function detectCookieBanner() {
    let banner = null;
    let bannerType = null;
    for (const selector of BANNER_SELECTORS) {
      try {
        banner = document.querySelector(selector);
        if (banner) {
          if (selector.includes("onetrust")) bannerType = "onetrust";
          else if (selector.includes("Cookiebot")) bannerType = "cookiebot";
          else bannerType = "custom";
          break;
        }
      } catch {
      }
    }
    if (!banner) {
      return {
        detected: false,
        hasRejectButton: false,
        isDarkPattern: false,
        type: null
      };
    }
    const buttons = banner.querySelectorAll('button, a[role="button"], [class*="button"]');
    let rejectButton = null;
    for (const btn of buttons) {
      const text = btn.textContent || "";
      if (REJECT_PATTERNS.test(text)) {
        rejectButton = btn;
        break;
      }
    }
    let isDarkPattern = false;
    if (!rejectButton) {
      isDarkPattern = true;
    } else {
      const style = getComputedStyle(rejectButton);
      const rect = rejectButton.getBoundingClientRect();
      if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0" || rect.width < 10 || rect.height < 10) {
        isDarkPattern = true;
      }
      const acceptButton = [...buttons].find((btn) => {
        const text = btn.textContent || "";
        return /accept|agree|allow|ok|got it/i.test(text);
      });
      if (acceptButton && rejectButton) {
        const acceptStyle = getComputedStyle(acceptButton);
        const rejectStyle = getComputedStyle(rejectButton);
        const acceptSize = parseFloat(acceptStyle.fontSize);
        const rejectSize = parseFloat(rejectStyle.fontSize);
        if (rejectSize < acceptSize * 0.8) {
          isDarkPattern = true;
        }
      }
    }
    return {
      detected: true,
      hasRejectButton: !!rejectButton,
      isDarkPattern,
      type: bannerType
    };
  }
  function analyzeForms() {
    const forms = document.querySelectorAll("form");
    const sensitiveInputs = document.querySelectorAll(`
    input[type="email"],
    input[type="tel"],
    input[type="password"],
    input[name*="email"],
    input[name*="phone"],
    input[name*="ssn"],
    input[name*="social"],
    input[name*="credit"],
    input[name*="card"],
    input[name*="cvv"],
    input[name*="passport"],
    input[name*="license"],
    input[autocomplete="email"],
    input[autocomplete="tel"],
    input[autocomplete="cc-number"]
  `);
    const hiddenInputs = document.querySelectorAll('input[type="hidden"]');
    return {
      count: forms.length,
      sensitiveFields: sensitiveInputs.length,
      hasHiddenInputs: hiddenInputs.length > 0
    };
  }
  function findPrivacyPolicyLink() {
    const selectors = [
      'a[href*="privacy"]',
      'a[href*="datenschutz"]',
      'a[href*="privacidade"]',
      'a[href*="confidentialite"]'
    ];
    for (const selector of selectors) {
      const link = document.querySelector(selector);
      if (link?.href) {
        return link.href;
      }
    }
    return null;
  }
  function calculateGapScore(trackers, cookieBanner, forms) {
    let score = 20;
    score += Math.min(50, trackers.length * 5);
    const adTrackers = trackers.filter((t) => t.category === "advertising");
    score += adTrackers.length * 3;
    const sessionRecording = trackers.filter((t) => t.category === "session-recording");
    score += sessionRecording.length * 5;
    if (cookieBanner.detected) {
      if (cookieBanner.isDarkPattern) score += 20;
      if (!cookieBanner.hasRejectButton) score += 15;
    }
    score += forms.sensitiveFields * 3;
    if (forms.hasHiddenInputs) score += 5;
    return Math.min(100, Math.max(0, score));
  }

  // src/content/repertoire-sync.ts
  var lastSyncTimestamp = 0;
  var syncInProgress = false;
  function shouldSync() {
    const hostname = location.hostname.toLowerCase();
    return SYNC_DOMAINS.some(
      (domain) => hostname === domain || hostname === `www.${domain}`
    );
  }
  async function syncRepertoireFromWebsite() {
    if (!shouldSync()) {
      return { success: false, reason: "wrong_domain" };
    }
    if (syncInProgress) {
      return { success: false, reason: "sync_in_progress" };
    }
    syncInProgress = true;
    try {
      const raw = localStorage.getItem(REPERTOIRE_STORAGE_KEY);
      if (!raw) {
        return { success: false, reason: "no_repertoire" };
      }
      const repertoire = parseRepertoire(raw);
      if (!repertoire) {
        return { success: false, reason: "invalid_repertoire" };
      }
      const existing = await getStoredRepertoire();
      if (existing && existing.lastUpdated >= repertoire.lastUpdated) {
        return { success: true, reason: "already_synced", spellCount: existing.learnedSpells.length };
      }
      await chrome.storage.local.set({
        spell_repertoire: repertoire,
        repertoire_synced_at: Date.now()
      });
      lastSyncTimestamp = Date.now();
      console.log("[Swordsman] Synced", repertoire.learnedSpells.length, "spells from training ground");
      chrome.runtime.sendMessage({
        type: "REPERTOIRE_SYNCED",
        spellCount: repertoire.learnedSpells.length,
        trainingProgress: repertoire.trainingProgress
      });
      return {
        success: true,
        reason: "synced",
        spellCount: repertoire.learnedSpells.length,
        repertoire
      };
    } catch (error) {
      console.error("[Swordsman] Sync failed:", error);
      return { success: false, reason: "error", error: String(error) };
    } finally {
      syncInProgress = false;
    }
  }
  async function getStoredRepertoire() {
    const data = await chrome.storage.local.get("spell_repertoire");
    return data.spell_repertoire || null;
  }
  async function getLearnedSpells() {
    const repertoire = await getStoredRepertoire();
    return repertoire?.learnedSpells || [];
  }
  var storageObserver = null;
  function startStorageObserver() {
    if (!shouldSync()) return;
    if (storageObserver) return;
    window.addEventListener("storage", async (event) => {
      if (event.key === REPERTOIRE_STORAGE_KEY && event.newValue) {
        console.log("[Swordsman] Detected repertoire update");
        await syncRepertoireFromWebsite();
      }
    });
    const pollInterval = setInterval(async () => {
      if (!shouldSync()) {
        clearInterval(pollInterval);
        return;
      }
      await syncRepertoireFromWebsite();
    }, 5e3);
    console.log("[Swordsman] Storage observer started");
  }
  async function initRepertoireSync() {
    const result = await syncRepertoireFromWebsite();
    if (result.success && result.reason === "synced") {
      console.log(`[Swordsman] Initial sync complete: ${result.spellCount} spells`);
    }
    startStorageObserver();
  }

  // src/content/blade-forge.ts
  function analyzeDimensions(page) {
    const d1Hide = calculateHideScore(page);
    const d2Commit = calculateCommitScore(page);
    const d3Prove = calculateProveScore(page);
    const d4Connect = calculateConnectScore(page);
    const d5Reflect = calculateReflectScore(page);
    const d6Delegate = calculateDelegateScore(page);
    return { d1Hide, d2Commit, d3Prove, d4Connect, d5Reflect, d6Delegate };
  }
  function calculateHideScore(page) {
    let score = 1;
    score -= page.trackerCount * 0.05;
    score -= page.cookieBannerDetected ? 0.1 : 0;
    score -= page.darkPatterns.length * 0.15;
    if (page.isHomeTurf) score += 0.3;
    return Math.max(0, Math.min(1, score));
  }
  function calculateCommitScore(page) {
    let score = 0.3;
    if (page.isHomeTurf) score += 0.5;
    if (page.hasPrivacyPolicy) score += 0.1;
    return Math.max(0, Math.min(1, score));
  }
  function calculateProveScore(page) {
    let score = 0.2;
    if (page.isHomeTurf) score = 0.9;
    score += (10 - Math.min(10, page.trackerCount)) * 0.03;
    return Math.max(0, Math.min(1, score));
  }
  function calculateConnectScore(page) {
    let score = 0.5;
    score -= page.trackerCount * 0.04;
    if (page.isHomeTurf) score = 1;
    return Math.max(0, Math.min(1, score));
  }
  function calculateReflectScore(page) {
    let score = 0.3;
    if (page.hasPrivacyPolicy) score += 0.2;
    if (page.isHomeTurf) score = 0.95;
    return Math.max(0, Math.min(1, score));
  }
  function calculateDelegateScore(page) {
    let score = 0.5;
    score -= page.trackerCount * 0.05;
    if (page.cookieBannerDetected) score -= 0.15;
    if (page.isHomeTurf) score = 1;
    return Math.max(0, Math.min(1, score));
  }
  function dimensionsToHexagram(dims) {
    const threshold = 0.5;
    return [
      dims.d1Hide >= threshold ? 1 : 0,
      dims.d2Commit >= threshold ? 1 : 0,
      dims.d3Prove >= threshold ? 1 : 0,
      dims.d4Connect >= threshold ? 1 : 0,
      dims.d5Reflect >= threshold ? 1 : 0,
      dims.d6Delegate >= threshold ? 1 : 0
    ];
  }
  function hexagramToBladeId(hex) {
    return hex[0] + hex[1] * 2 + hex[2] * 4 + hex[3] * 8 + hex[4] * 16 + hex[5] * 32;
  }
  function getBladeLayer(bladeId) {
    let yangCount = 0;
    let n = bladeId;
    while (n) {
      yangCount += n & 1;
      n >>= 1;
    }
    return yangCount;
  }
  function getHexagramNumber(bladeId) {
    const kingWen = [
      2,
      23,
      8,
      20,
      16,
      35,
      45,
      12,
      // 0-7
      15,
      52,
      39,
      53,
      62,
      56,
      31,
      33,
      // 8-15
      7,
      4,
      29,
      59,
      40,
      64,
      47,
      6,
      // 16-23
      46,
      18,
      48,
      57,
      32,
      50,
      28,
      44,
      // 24-31
      24,
      27,
      3,
      42,
      51,
      21,
      17,
      25,
      // 32-39
      36,
      22,
      63,
      37,
      55,
      30,
      49,
      13,
      // 40-47
      19,
      41,
      60,
      61,
      54,
      38,
      58,
      10,
      // 48-55
      11,
      26,
      5,
      9,
      34,
      14,
      43,
      1
      // 56-63
    ];
    return kingWen[bladeId];
  }
  var HEXAGRAM_NAMES = {
    1: "The Creative (Qian)",
    2: "The Receptive (Kun)",
    3: "Difficulty at the Beginning",
    4: "Youthful Folly",
    5: "Waiting",
    6: "Conflict",
    7: "The Army",
    8: "Holding Together",
    // ... full 64 would be added
    63: "After Completion",
    64: "Before Completion"
  };
  function createBladeFromHexagram(hex) {
    const bladeId = hexagramToBladeId(hex);
    const layer = getBladeLayer(bladeId);
    const hexNumber = getHexagramNumber(bladeId);
    const layerEmojis = ["\u26AB", "\u{1F5E1}\uFE0F", "\u2694\uFE0F", "\u{1F531}", "\u{1F4A0}", "\u{1F31F}", "\u{1F409}"];
    const yangLineAssertions = [
      "SELF_CUSTODY",
      "SELECTIVE_DISCLOSURE",
      "SELF_EXECUTE",
      "LOCAL_DATA",
      "FIRST_PERSON",
      "CLOSED_PERIMETER"
    ];
    const activeTerms = hex.map((line, i) => line === 1 ? yangLineAssertions[i] : null).filter(Boolean);
    return {
      id: bladeId,
      name: HEXAGRAM_NAMES[hexNumber] || `Blade ${bladeId}`,
      layer,
      edges: layer,
      // Number of active dimensions
      hexagram: hex,
      assertion: {
        terms: activeTerms,
        emoji: layerEmojis[layer],
        description: `Layer ${layer} blade with ${layer} active privacy dimensions`
      },
      zk: {
        statement: `User asserts ${activeTerms.join(" \u2227 ")}`,
        witnessType: "spell_constellation_hash",
        verifiable: layer >= 3
        // Layer 3+ can be verified on-chain
      },
      unlock: {
        requiredLevel: Math.max(0, layer - 1),
        requiredForgings: layer * 3,
        requiredDomains: Math.floor(layer / 2)
      }
    };
  }
  var state = {
    forge: {
      currentLayer: 0,
      highestBlade: null,
      forgings: [],
      totalForgings: 0,
      domainsForged: [],
      unlockedBlades: [0],
      // Start with null blade
      progress: {
        forgingsToNextLayer: 3,
        domainsToNextLayer: 1
      }
    },
    currentPageDimensions: null,
    currentPageHexagram: null,
    pendingForging: null
  };
  async function initializeForge() {
    const stored = await chrome.storage.local.get("blade_forge");
    if (stored.blade_forge) {
      state.forge = stored.blade_forge;
    }
    return state.forge;
  }
  async function saveForge() {
    await chrome.storage.local.set({ blade_forge: state.forge });
  }
  function analyzePageForForging(page) {
    const dimensions = analyzeDimensions(page);
    const hexagram = dimensionsToHexagram(dimensions);
    const potentialBlade = createBladeFromHexagram(hexagram);
    const canForge = checkCanForge(potentialBlade);
    state.currentPageDimensions = dimensions;
    state.currentPageHexagram = hexagram;
    return { dimensions, hexagram, potentialBlade, canForge };
  }
  function checkCanForge(blade) {
    if (state.forge.unlockedBlades.includes(blade.id)) {
      return true;
    }
    const { requiredLevel, requiredForgings, requiredDomains } = blade.unlock;
    if (state.forge.currentLayer < requiredLevel) return false;
    if (requiredForgings && state.forge.totalForgings < requiredForgings) return false;
    if (requiredDomains && state.forge.domainsForged.length < requiredDomains) return false;
    return true;
  }
  async function forgeBlade(spellSignatures, constellationHash) {
    if (!state.currentPageHexagram) {
      console.warn("[BladeForge] No hexagram computed for current page");
      return null;
    }
    const blade = createBladeFromHexagram(state.currentPageHexagram);
    if (!checkCanForge(blade)) {
      console.warn("[BladeForge] Cannot forge blade", blade.id, "- requirements not met");
      return null;
    }
    const forging = {
      id: crypto.randomUUID(),
      blade,
      domain: location.hostname,
      timestamp: Date.now(),
      witness: {
        constellationHash,
        signatureChain: spellSignatures,
        hexagramAtForge: state.currentPageHexagram
      },
      proof: {
        type: "local"
      }
    };
    state.forge.forgings.push(forging);
    state.forge.totalForgings++;
    if (!state.forge.domainsForged.includes(forging.domain)) {
      state.forge.domainsForged.push(forging.domain);
    }
    if (!state.forge.unlockedBlades.includes(blade.id)) {
      state.forge.unlockedBlades.push(blade.id);
    }
    if (!state.forge.highestBlade || blade.layer > state.forge.highestBlade.layer) {
      state.forge.highestBlade = blade;
    }
    updateLayerProgression();
    await saveForge();
    console.log("[BladeForge] Forged blade:", blade.name, "layer:", blade.layer);
    return forging;
  }
  function updateLayerProgression() {
    const { totalForgings, domainsForged, currentLayer } = state.forge;
    const vrcThresholds = [1, 3, 10, 15, 30, 50];
    const domainThresholds = [0, 1, 3, 5, 10, 20];
    let newLayer = 0;
    for (let i = 0; i < vrcThresholds.length; i++) {
      if (totalForgings >= vrcThresholds[i] && domainsForged.length >= domainThresholds[i]) {
        newLayer = i;
      }
    }
    if (newLayer > currentLayer) {
      state.forge.currentLayer = newLayer;
      console.log("[BladeForge] LEVEL UP! Now at layer", newLayer);
    }
    const nextLevel = Math.min(6, currentLayer + 1);
    state.forge.progress = {
      forgingsToNextLayer: Math.max(0, vrcThresholds[nextLevel] - totalForgings),
      domainsToNextLayer: Math.max(0, domainThresholds[nextLevel] - domainsForged.length)
    };
  }
  function getForgeState() {
    return state.forge;
  }

  // src/content/evoke.ts
  var GRIMOIRE_ACTS = [
    // Story Spellbook (WHAT)
    {
      id: "act-01-venice",
      actNumber: 1,
      title: "Venice, 1494 / The Drake's First Whisper",
      spell: "\u{1F4D6}\u{1F4B0} \u2192 \u{1F409}\u23F3 \u2192 \u2694\uFE0F\u{1F52E}",
      proverb: "The ledger that balances itself in darkness still casts a shadow in the light.",
      spellbook: "story",
      vrcLevel: 1,
      layerRequired: 0
    },
    {
      id: "act-02-ceremony",
      actNumber: 2,
      title: "The First Ceremony",
      spell: "\u{1F5E1}\uFE0F \u2192 \u{1F36A}\u2694\uFE0F \u2192 \u{1F512} \u2192 \u{1F4D6}\u{1F4DD} \u2192 \u{1F91D}\u{1F4DC}\u2081",
      proverb: "Trust begins unarmored\u2014the swordsman and mage test small betrayals before the first person may grant the keys to more powerful treasures.",
      spellbook: "story",
      vrcLevel: 1,
      layerRequired: 1
    },
    {
      id: "act-03-monastery",
      actNumber: 3,
      title: "The Digital Monastery",
      spell: "\u{1F510}\u26E9\uFE0F \u2192 \u{1F6E1}\uFE0F \u2192 \u2728\u{1F4D6} \u2192 \u2696\uFE0F",
      proverb: "What is known selectively is power; what is known fully is surrender.",
      spellbook: "story",
      vrcLevel: 3,
      layerRequired: 2
    },
    // ZK Spellbook (HOW)
    {
      id: "act-04-proof",
      actNumber: 4,
      title: "The Zero Knowledge Proof",
      spell: "\u{1F3AD} \u2192 \u{1F50F} \u2192 \u2713 \u2192 \u{1F6AB}\u{1F441}\uFE0F",
      proverb: "To prove without revealing is the highest form of trust.",
      spellbook: "zk",
      vrcLevel: 3,
      layerRequired: 2
    },
    {
      id: "act-05-commitment",
      actNumber: 5,
      title: "The Commitment Scheme",
      spell: "\u{1F4E6}\u{1F512} \u2192 \u23F0 \u2192 \u{1F4E6}\u{1F513} \u2192 \u2713",
      proverb: "A promise locked is worth more than a promise spoken.",
      spellbook: "zk",
      vrcLevel: 10,
      layerRequired: 3
    },
    {
      id: "act-06-nullifier",
      actNumber: 6,
      title: "The Nullifier",
      spell: "\u{1F3AB} \u2192 \u274C \u2192 \u{1F504}\u{1F6AB} \u2192 \u2713",
      proverb: "What has been spent cannot be spent again; this is the law of integrity.",
      spellbook: "zk",
      vrcLevel: 10,
      layerRequired: 3
    },
    // Canon Spellbook (WHY)
    {
      id: "act-07-zcash",
      actNumber: 7,
      title: "The Zcash Protocol",
      spell: "\u{1F48E}\u{1F6E1}\uFE0F \u2192 \u{1F310} \u2192 \u26A1 \u2192 \u{1F510}",
      proverb: "Privacy is not secrecy; it is the power to selectively reveal oneself.",
      spellbook: "canon",
      vrcLevel: 15,
      layerRequired: 4
    },
    {
      id: "act-08-inscription",
      actNumber: 8,
      title: "The On-Chain Inscription",
      spell: "\u{1F4DC} \u2192 \u26D3\uFE0F \u2192 \u{1F52E} \u2192 \u221E",
      proverb: "What is inscribed endures; what endures becomes law.",
      spellbook: "canon",
      vrcLevel: 15,
      layerRequired: 4
    },
    {
      id: "act-09-wallet",
      actNumber: 9,
      title: "The Sovereign Wallet",
      spell: "\u{1F511}\u{1F3E0} \u2192 \u{1F6E1}\uFE0F \u2192 \u{1F5C2}\uFE0F \u2192 \u{1F464}",
      proverb: "Your keys, your castle; your data, your domain.",
      spellbook: "canon",
      vrcLevel: 30,
      layerRequired: 5
    },
    // Parallel Society Spellbook (EXIT)
    {
      id: "act-10-exit",
      actNumber: 10,
      title: "The Right to Exit",
      spell: "\u{1F6AA} \u2192 \u{1F3C3} \u2192 \u{1F30D} \u2192 \u{1F193}",
      proverb: "Freedom is not granted but exercised through the door always open.",
      spellbook: "parallel",
      vrcLevel: 30,
      layerRequired: 5
    },
    {
      id: "act-11-pseudonym",
      actNumber: 11,
      title: "The Pseudonymous Identity",
      spell: "\u{1F464}\u{1F3AD} \u2192 \u{1F517} \u2192 \u{1F310} \u2192 \u{1F512}",
      proverb: "A name chosen is more honest than a name inherited.",
      spellbook: "parallel",
      vrcLevel: 30,
      layerRequired: 5
    },
    {
      id: "act-12-network",
      actNumber: 12,
      title: "The Parallel Network",
      spell: "\u{1F310}\u{1F500} \u2192 \u{1F91D} \u2192 \u{1F3D7}\uFE0F \u2192 \u{1F331}",
      proverb: "Build the world you wish to live in; do not wait for permission.",
      spellbook: "parallel",
      vrcLevel: 30,
      layerRequired: 5
    },
    // Plurality Spellbook (COORDINATE)
    {
      id: "act-13-quadratic",
      actNumber: 13,
      title: "The Quadratic Mechanism",
      spell: "\u{1F4CA}\xB2 \u2192 \u2696\uFE0F \u2192 \u{1F5F3}\uFE0F \u2192 \u{1F91D}",
      proverb: "The square of voices is more just than the sum.",
      spellbook: "plurality",
      vrcLevel: 50,
      layerRequired: 6
    },
    {
      id: "act-14-sybil",
      actNumber: 14,
      title: "The Sybil Resistance",
      spell: "\u{1F465}\u274C \u2192 \u{1F50D} \u2192 \u2713 \u2192 \u{1F6E1}\uFE0F",
      proverb: "One person, one voice\u2014the foundation of coordination.",
      spellbook: "plurality",
      vrcLevel: 50,
      layerRequired: 6
    },
    {
      id: "act-15-drake",
      actNumber: 15,
      title: "The Drake Awakens",
      spell: "\u{1F409} \u2192 \u{1F525} \u2192 \u2694\uFE0F\u{1F52E} \u2192 \u{1F451}",
      proverb: "When swordsman and mage align, the drake rises to guard the realm.",
      spellbook: "plurality",
      vrcLevel: 50,
      layerRequired: 6
    }
  ];
  function findMatchingAct(blade, currentLayer) {
    const eligible = GRIMOIRE_ACTS.filter(
      (act) => currentLayer >= act.layerRequired
    );
    if (eligible.length === 0) return null;
    const sorted = eligible.sort((a, b) => {
      const aDistance = Math.abs(a.layerRequired - blade.layer);
      const bDistance = Math.abs(b.layerRequired - blade.layer);
      return aDistance - bDistance;
    });
    return sorted[0];
  }
  function calculateMatchScore(blade, act) {
    const layerDiff = Math.abs(blade.layer - act.layerRequired);
    let score = 1 - layerDiff / 6;
    const primaryDim = blade.hexagram.findIndex((l) => l === 1) + 1;
    const spellbookDimMap = {
      "story": 5,
      // d5Reflect
      "zk": 2,
      // d2Commit
      "canon": 4,
      // d4Connect
      "parallel": 1,
      // d1Hide
      "plurality": 6
      // d6Delegate
    };
    if (spellbookDimMap[act.spellbook] === primaryDim) {
      score += 0.2;
    }
    return Math.min(1, score);
  }
  function createEvocation(blade, currentLayer) {
    const act = findMatchingAct(blade, currentLayer);
    if (!act) return null;
    return {
      id: crypto.randomUUID(),
      act,
      blade,
      timestamp: Date.now(),
      domain: location.hostname,
      matchScore: calculateMatchScore(blade, act)
    };
  }
  function formatEvocation(evocation) {
    const { act, blade, matchScore } = evocation;
    return `
\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551  ${act.spell}
\u2551
\u2551  "${act.proverb}"
\u2551
\u2551  \u2014 Act ${act.actNumber}: ${act.title}
\u2551
\u2551  Blade: ${blade.name} (Layer ${blade.layer})
\u2551  Match: ${Math.round(matchScore * 100)}%
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D
  `.trim();
  }
  function getEvocationForForging(blade, currentLayer) {
    const evocation = createEvocation(blade, currentLayer);
    if (!evocation) return null;
    return {
      text: formatEvocation(evocation),
      spell: evocation.act.spell,
      proverb: evocation.act.proverb
    };
  }

  // src/content/index.ts
  var renderer = null;
  var tether = null;
  var mouse = null;
  var channel = null;
  var renderMode = "single";
  var pageAnalysis = null;
  var isRunning = false;
  var localSpellNodes = [];
  var forgeAnalysis = null;
  var isHomeTerritoryPage = false;
  var homeTerritoryType = null;
  var animParams = {
    orbitRadii: 1,
    spellSpawnRate: 0.5,
    phaseCoupling: 0.5,
    edgeThreshold: 180,
    glowIntensity: 0.3,
    gridVisibility: 0.05
  };
  var HOME_DOMAINS = [
    "agentprivacy.ai",
    "www.agentprivacy.ai",
    "spellweb.ai",
    "www.spellweb.ai",
    "bgin.ai",
    "www.bgin.ai",
    // Local development
    "localhost",
    "127.0.0.1"
  ];
  function checkHomeTerritory() {
    const host = location.hostname.replace("www.", "");
    const port = location.port;
    isHomeTerritoryPage = HOME_DOMAINS.includes(host);
    if ((host === "localhost" || host === "127.0.0.1") && port === "5000") {
      isHomeTerritoryPage = true;
    }
    if (isHomeTerritoryPage) {
      if (host === "agentprivacy.ai" || host === "localhost" || host === "127.0.0.1") {
        homeTerritoryType = "agentprivacy";
      } else if (host === "spellweb.ai") {
        homeTerritoryType = "spellweb";
      } else if (host === "bgin.ai") {
        homeTerritoryType = "bgin";
      }
      console.log("[Swordsman Content] Home territory detected:", homeTerritoryType);
    }
  }
  function activateHomeTerritoryMode() {
    console.log("[Swordsman Content] Activating home territory mode:", homeTerritoryType);
    window.addEventListener("message", handleWebsiteMessage);
    announceToWebsite();
    setInterval(announceToWebsite, 5e3);
  }
  function announceToWebsite() {
    const orbPos = tether ? { x: tether.x, y: tether.y } : { x: 0, y: 0 };
    window.postMessage({
      type: "SWORD_PRESENT",
      domain: location.hostname,
      orbPosition: orbPos,
      homeTerritoryType,
      myTermsState: getForgeState(),
      capabilities: ["spring-physics", "blade-forge", "convergence", "ceremony"]
    }, "*");
  }
  function handleWebsiteMessage(event) {
    if (event.origin !== location.origin) return;
    const { data } = event;
    if (!data || !data.type) return;
    switch (data.type) {
      case "WEBSITE_READY":
        console.log("[Swordsman Content] Website ready, capabilities:", data.capabilities);
        announceToWebsite();
        break;
      case "SPELL_CAST":
        console.log("[Swordsman Content] Website spell cast:", data.spellId);
        break;
      case "ORB_CONVERGENCE":
        console.log("[Swordsman Content] Website orb convergence:", data.count);
        break;
      case "PATH_UNLOCKED":
        console.log("[Swordsman Content] Path unlocked on website!", data.progress);
        break;
      case "REPERTOIRE_SYNC":
        console.log("[Swordsman Content] Repertoire sync from website");
        break;
    }
  }
  function initialize() {
    console.log("[Swordsman Content] Initializing...");
    checkHomeTerritory();
    renderer = new OrbRenderer();
    const initialPos = {
      x: window.innerWidth - 100,
      y: window.innerHeight - 100
    };
    tether = new SpringTether(initialPos.x, initialPos.y);
    mouse = new MouseTracker();
    channel = new CeremonyChannel(createChannelCallbacks());
    pageAnalysis = analyzePage();
    console.log("[Swordsman Content] Page analysis:", pageAnalysis.domain, "gap:", pageAnalysis.gapScore);
    chrome.runtime.sendMessage({
      type: "PAGE_ANALYSIS",
      data: pageAnalysis
    });
    renderer.setGapScore(pageAnalysis.gapScore);
    initializeForge().then((forge) => {
      console.log("[Swordsman Content] Forge initialized, layer:", forge.currentLayer);
      forgeAnalysis = analyzePageForForging(pageAnalysis);
      console.log("[Swordsman Content] Page hexagram:", forgeAnalysis.hexagram);
      console.log("[Swordsman Content] Potential blade:", forgeAnalysis.potentialBlade.name);
      if (forgeAnalysis.hexagram) {
        channel?.setHexagramState({
          lines: forgeAnalysis.hexagram,
          number: forgeAnalysis.potentialBlade.id + 1,
          name: forgeAnalysis.potentialBlade.name
        });
      }
    });
    initRepertoireSync().then(async () => {
      const spells = await getLearnedSpells();
      console.log("[Swordsman Content] Learned spells:", spells.length);
    });
    channel.startDiscovery();
    startRenderLoop();
    setupEventListeners();
    if (isHomeTerritoryPage) {
      activateHomeTerritoryMode();
    }
    console.log("[Swordsman Content] Initialization complete");
  }
  function createChannelCallbacks() {
    return {
      onMageDetected: (orbPosition, spellbookState) => {
        console.log("[Swordsman Content] Mage detected at:", orbPosition);
        renderMode = "dual";
        renderer?.setMagePosition(orbPosition.x, orbPosition.y);
        renderer?.setMageVisible(true);
      },
      onMageDisconnected: () => {
        console.log("[Swordsman Content] Mage disconnected");
        renderMode = "single";
        renderer?.setMageVisible(false);
      },
      onMageOrbPosition: (x, y) => {
        renderer?.setMagePosition(x, y);
      },
      onConstellationUpdate: (nodes, edges, patterns) => {
        const allNodes = [...localSpellNodes, ...nodes];
        renderer?.setConstellation(allNodes, edges, patterns);
      },
      onConstellationWave: (payload, animation) => {
        console.log("[Swordsman Content] Constellation wave received:", payload);
        if (payload.gapScore !== void 0) {
          renderer?.setGapScore(payload.gapScore);
        }
      },
      onScanResults: (findings) => {
        console.log("[Swordsman Content] Mage scan results:", findings.domain);
        renderer?.setGapScore(findings.gapScore);
      },
      onHexagramUpdate: (state2, params) => {
        console.log("[Swordsman Content] Hexagram update:", state2.number || "unknown");
        animParams = params;
        renderer?.setAnimationParams(params);
        channel?.setHexagramState(state2);
      },
      onDrakeFormation: (bodyNodes, patrolPath, progress) => {
        console.log("[Swordsman Content] Drake formation:", progress);
        renderer?.setDrakeFormation(bodyNodes, patrolPath, progress);
      },
      onCeremonyBegin: (ceremonyType, initiator) => {
        console.log("[Swordsman Content] Ceremony begin:", ceremonyType, "by", initiator);
      },
      onSpellCast: (spell) => {
        console.log("[Swordsman Content] Mage spell cast:", spell);
      }
    };
  }
  function startRenderLoop() {
    isRunning = true;
    function render() {
      if (!isRunning || !renderer || !tether || !mouse) return;
      const mousePos = mouse.getPosition();
      const orbPos = tether.update(mousePos.x, mousePos.y);
      renderer.setSwordsmanPosition(orbPos.x, orbPos.y);
      channel?.updateOrbPosition(orbPos.x, orbPos.y);
      renderer.render();
      requestAnimationFrame(render);
    }
    requestAnimationFrame(render);
  }
  function stopRenderLoop() {
    isRunning = false;
  }
  function setupEventListeners() {
    document.addEventListener("click", handleClick);
    document.addEventListener("contextmenu", handleContextMenu);
    chrome.runtime.onMessage.addListener(handleBackgroundMessage);
    document.addEventListener("keydown", handleKeydown);
  }
  function handleClick(e) {
    if (e.altKey) {
      e.preventDefault();
      castSpell({
        type: "emoji",
        content: "\u{1F6E1}\uFE0F",
        yangYin: "yang"
      }, { x: e.clientX, y: e.clientY });
    }
  }
  function handleContextMenu(e) {
  }
  function handleBackgroundMessage(message, sender, sendResponse) {
    switch (message.type) {
      case "CAST_SPELL":
        if (mouse) {
          castSpell(message.spell, mouse.getPosition());
        }
        sendResponse({ success: true });
        break;
      case "GET_STATE":
        sendResponse({
          renderMode,
          magePresent: channel?.isMagePresent(),
          gapScore: pageAnalysis?.gapScore,
          localSpellCount: localSpellNodes.length
        });
        break;
      default:
        sendResponse({ received: true });
    }
  }
  function handleKeydown(e) {
    if (e.ctrlKey && e.shiftKey) {
      switch (e.key) {
        case "1":
          if (mouse) {
            castSpell({
              type: "keyword",
              content: "DO_NOT_TRACK",
              yangYin: "yang"
            }, mouse.getPosition());
          }
          e.preventDefault();
          break;
        case "2":
          if (mouse) {
            castSpell({
              type: "keyword",
              content: "DATA_MINIMISATION",
              yangYin: "yang"
            }, mouse.getPosition());
          }
          e.preventDefault();
          break;
        case "3":
          if (mouse) {
            castSpell({
              type: "emoji",
              content: "\u{1F6E1}\uFE0F",
              yangYin: "yang"
            }, mouse.getPosition());
          }
          e.preventDefault();
          break;
      }
    }
  }
  function castSpell(spell, position) {
    console.log("[Swordsman Content] Casting spell:", spell.content, "at", position);
    const node = {
      id: crypto.randomUUID(),
      x: position.x,
      y: position.y,
      yangYin: spell.yangYin,
      opacity: 1,
      pulse: 1,
      // Start with pulse animation
      emoji: spell.type === "emoji" ? spell.content : void 0
    };
    localSpellNodes.push(node);
    let pulseStart = performance.now();
    function animatePulse() {
      const elapsed = performance.now() - pulseStart;
      const progress = Math.min(1, elapsed / 1e3);
      node.pulse = 1 - progress;
      if (progress < 1) {
        requestAnimationFrame(animatePulse);
      }
    }
    requestAnimationFrame(animatePulse);
    chrome.runtime.sendMessage({
      type: "SPELL_CAST",
      spell: {
        ...spell,
        id: node.id,
        position,
        timestamp: Date.now()
      }
    });
    if (channel?.isMagePresent()) {
      channel.sendToMage({
        type: "SLASH",
        target: "page",
        domain: location.hostname,
        assertion: spell.content,
        intensity: 5
      });
    }
    updateLocalConstellation();
    checkAndForge();
  }
  async function checkAndForge() {
    if (localSpellNodes.length < 3) return;
    if (!forgeAnalysis || !forgeAnalysis.canForge) return;
    const spellSignatures = localSpellNodes.map((n) => n.id);
    const constellationHash = generateConstellationHash(localSpellNodes);
    const forging = await forgeBlade(spellSignatures, constellationHash);
    if (forging) {
      console.log("[Swordsman Content] BLADE FORGED:", forging.blade.name);
      const forge = getForgeState();
      const evocation = getEvocationForForging(forging.blade, forge.currentLayer);
      if (evocation) {
        console.log("[Swordsman Content] Evocation:", evocation.proverb);
        chrome.runtime.sendMessage({
          type: "BLADE_FORGED",
          forging: {
            bladeId: forging.blade.id,
            bladeName: forging.blade.name,
            layer: forging.blade.layer,
            domain: forging.domain
          },
          evocation: {
            spell: evocation.spell,
            proverb: evocation.proverb
          }
        });
      }
      localSpellNodes = [];
      updateLocalConstellation();
    }
  }
  function generateConstellationHash(nodes) {
    const data = nodes.map((n) => `${n.x},${n.y},${n.yangYin}`).join("|");
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      hash = (hash << 5) - hash + data.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }
  function updateLocalConstellation() {
    const edges = [];
    for (let i = 0; i < localSpellNodes.length; i++) {
      for (let j = i + 1; j < localSpellNodes.length; j++) {
        const dx = localSpellNodes[i].x - localSpellNodes[j].x;
        const dy = localSpellNodes[i].y - localSpellNodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < animParams.edgeThreshold) {
          const sameType = localSpellNodes[i].yangYin === localSpellNodes[j].yangYin;
          edges.push({
            from: localSpellNodes[i].id,
            to: localSpellNodes[j].id,
            strength: 1 - dist / animParams.edgeThreshold,
            type: sameType ? "solid" : "dashed"
          });
        }
      }
    }
    if (!channel?.isMagePresent()) {
      renderer?.setConstellation(localSpellNodes, edges, []);
    }
  }
  function checkConvergence() {
    if (!channel?.isMagePresent()) return;
    const distance = channel.getOrbDistance();
    const CONVERGENCE_THRESHOLD = 60;
    if (distance < CONVERGENCE_THRESHOLD && localSpellNodes.length > 0) {
      triggerConvergence();
    }
  }
  function triggerConvergence() {
    console.log("[Swordsman Content] CONVERGENCE TRIGGERED!");
    channel?.sendCeremonyBegin("dual_convergence");
    chrome.runtime.sendMessage({
      type: "CONVERGENCE",
      spellsCast: localSpellNodes.map((n) => ({
        id: n.id,
        content: n.emoji || "spell",
        yangYin: n.yangYin,
        position: { x: n.x, y: n.y }
      })),
      hexagramState: [1, 0, 1, 0, 1, 0]
      // TODO: Get from Mage
    });
  }
  setInterval(() => {
    if (channel?.isMagePresent()) {
      checkConvergence();
    }
  }, 500);
  function cleanup() {
    stopRenderLoop();
    renderer?.destroy();
    channel?.destroy();
    renderer = null;
    tether = null;
    mouse = null;
    channel = null;
  }
  window.addEventListener("unload", cleanup);
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }
  console.log("[Swordsman Content] Script loaded");
})();
//# sourceMappingURL=index.js.map
