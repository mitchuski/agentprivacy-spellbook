// ../shared/types/index.ts
var MAGE_EXTENSION_ID = "MAGE_EXTENSION_ID_PLACEHOLDER";

// src/background/index.ts
var myTermsState = null;
var mageDetected = false;
var sharedSecret = null;
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[Swordsman] Extension installed:", details.reason);
  if (details.reason === "install") {
    await initializeMyTerms();
    await loadSpellWalletFromTraining();
  }
  startMageDetection();
});
chrome.runtime.onStartup.addListener(async () => {
  console.log("[Swordsman] Extension started");
  await loadState();
  startMageDetection();
});
async function initializeMyTerms() {
  const defaultState = {
    preferences: {
      doNotTrack: true,
      doNotSell: true,
      dataMinimisation: true,
      cookiePreference: "essential-only",
      credentialDisclosure: "selective",
      agentDelegation: "self-only"
    },
    spellPalette: [],
    autoAssertDomains: []
  };
  await chrome.storage.local.set({ myTermsState: defaultState });
  myTermsState = defaultState;
  console.log("[Swordsman] MyTerms initialized");
}
async function loadState() {
  const data = await chrome.storage.local.get(["myTermsState", "bladeForge"]);
  myTermsState = data.myTermsState || null;
  console.log("[Swordsman] State loaded");
}
async function loadSpellWalletFromTraining() {
  const data = await chrome.storage.sync.get("spellWallet");
  if (data.spellWallet?.spells) {
    const spellIds = Object.keys(data.spellWallet.spells);
    console.log(`[Swordsman] Loaded ${spellIds.length} spells from training`);
    if (myTermsState) {
      myTermsState.spellPalette = spellIds;
      await chrome.storage.local.set({ myTermsState });
    }
  }
}
function startMageDetection() {
  setInterval(async () => {
    try {
      await chrome.runtime.sendMessage(MAGE_EXTENSION_ID, { type: "PING" });
      if (!mageDetected) {
        console.log("[Swordsman] Mage extension detected!");
        mageDetected = true;
        await performKeyExchange();
      }
    } catch {
      if (mageDetected) {
        console.log("[Swordsman] Mage extension disconnected");
        mageDetected = false;
        sharedSecret = null;
      }
    }
  }, 5e3);
}
async function performKeyExchange() {
  const keyPair = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveKey"]
  );
  const publicKey = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
  const response = await chrome.runtime.sendMessage(MAGE_EXTENSION_ID, {
    type: "KEY_EXCHANGE",
    publicKey
  });
  if (response?.publicKey) {
    const magePublicKey = await crypto.subtle.importKey(
      "jwk",
      response.publicKey,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      []
    );
    sharedSecret = await crypto.subtle.deriveKey(
      { name: "ECDH", public: magePublicKey },
      keyPair.privateKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
    console.log("[Swordsman] Key exchange complete");
  }
}
async function sendToMage(message) {
  if (!mageDetected) {
    console.log("[Swordsman] Mage not detected, message not sent");
    return;
  }
  try {
    await chrome.runtime.sendMessage(MAGE_EXTENSION_ID, message);
  } catch (error) {
    console.error("[Swordsman] Failed to send to Mage:", error);
  }
}
chrome.runtime.onMessageExternal.addListener(
  (message, sender, sendResponse) => {
    if (sender.id !== MAGE_EXTENSION_ID) {
      console.warn("[Swordsman] Received message from unknown extension");
      return;
    }
    handleMageMessage(message, sendResponse);
    return true;
  }
);
async function handleMageMessage(message, sendResponse) {
  switch (message.type) {
    case "MAGE_PRESENT":
      console.log("[Swordsman] Mage presence confirmed on:", message.domain);
      notifyContentScript({ type: "MAGE_DETECTED", analysis: message.analysis });
      sendResponse({ acknowledged: true });
      break;
    case "INTELLIGENCE":
      console.log("[Swordsman] Received intelligence:", message.suggestedBlade?.name);
      notifyContentScript({
        type: "INTELLIGENCE_RECEIVED",
        suggestedSpells: message.suggestedSpells,
        suggestedBlade: message.suggestedBlade
      });
      sendResponse({ acknowledged: true });
      break;
    case "HEXAGRAM_UPDATE":
      console.log("[Swordsman] Hexagram update:", message.hexagram.name);
      notifyContentScript({ type: "HEXAGRAM_UPDATE", hexagram: message.hexagram });
      sendResponse({ acknowledged: true });
      break;
    case "CONSTELLATION_WAVE":
      console.log("[Swordsman] Constellation wave received");
      notifyContentScript({ type: "WAVE_INCOMING", payload: message.payload });
      sendResponse({ acknowledged: true });
      break;
    case "CONVERGENCE_READY":
      console.log("[Swordsman] Mage ready for convergence");
      notifyContentScript({ type: "CONVERGENCE_READY", position: message.position });
      sendResponse({ acknowledged: true });
      break;
    case "KEY_EXCHANGE":
      sendResponse({ acknowledged: true });
      break;
    default:
      console.log("[Swordsman] Unknown message type:", message.type);
      sendResponse({ error: "Unknown message type" });
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleContentMessage(message, sender.tab?.id, sendResponse);
  return true;
});
async function handleContentMessage(message, tabId, sendResponse) {
  switch (message.type) {
    case "SPELL_CAST":
      await handleSpellCast(message, tabId);
      sendResponse({ success: true });
      break;
    case "CONVERGENCE":
      await handleConvergence(message, tabId);
      sendResponse({ success: true });
      break;
    case "REQUEST_STATE":
      sendResponse({
        myTermsState,
        mageDetected,
        bladeForge: await chrome.storage.local.get("bladeForge")
      });
      break;
    case "BROADCAST_TO_MAGE":
      await sendToMage(message.payload);
      sendResponse({ sent: true });
      break;
    default:
      sendResponse({ error: "Unknown message type" });
  }
}
async function handleSpellCast(message, tabId) {
  console.log("[Swordsman] Spell cast:", message.spell.content);
  const signedSpell = await signSpell(message.spell);
  await storeSpellNode(signedSpell, message.position, tabId);
  await sendToMage({
    type: "SPELL_CAST",
    spell: signedSpell,
    position: message.position,
    timestamp: Date.now()
  });
}
async function handleConvergence(message, tabId) {
  console.log("[Swordsman] Convergence triggered!");
  await sendToMage({
    type: "CONVERGENCE_INITIATED",
    spellsCast: message.spellsCast,
    convergencePoint: { x: 0, y: 0 }
    // TODO: Get actual position
  });
}
async function signSpell(spell) {
  return {
    ...spell,
    signature: "placeholder_signature",
    timestamp: Date.now(),
    signedBy: "swordsman"
  };
}
async function storeSpellNode(spell, position, tabId) {
  console.log("[Swordsman] Stored spell node at", position);
}
async function notifyContentScript(message) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]?.id) {
    chrome.tabs.sendMessage(tabs[0].id, message);
  }
}
console.log("[Swordsman] Background service worker initialized");
//# sourceMappingURL=index.js.map
