
const STORAGE_KEY = 'pretext_effect_library'
let currentDomain = ''

// Initialize popup
async function init() {
  // Get current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.url) return

  try {
    const url = new URL(tab.url)
    currentDomain = url.hostname
    document.getElementById('domain').textContent = currentDomain
  } catch {}

  // Load settings
  await loadSettings()

  // Request state from content script
  if (tab.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'GET_STATE' }, (response) => {
      if (chrome.runtime.lastError) return

      if (response) {
        document.getElementById('gap').textContent = response.gapScore ?? '—'

        if (response.magePresent) {
          document.getElementById('mage-dot').style.opacity = '1'
          document.getElementById('mage-status').textContent = 'Connected'
        }
      }
    })
  }
}

// Load settings from storage
async function loadSettings() {
  const result = await chrome.storage.local.get(STORAGE_KEY)
  const library = result[STORAGE_KEY]

  if (library) {
    // Set active extension mode
    const mode = library.settings?.activeExtension || 'dual'
    updateToggleUI(mode)

    // Set active effect
    const effectId = library.activeEffectId || 'blade-classic'
    updateEffectUI(effectId)

    // Check if domain is disabled
    if (library.settings?.disabledDomains?.includes(currentDomain)) {
      document.getElementById('disable-btn').textContent = 'Enable on this site'
    }
  }
}

// Update toggle button UI
function updateToggleUI(mode) {
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.classList.remove('active')
    if (btn.dataset.mode === mode) {
      btn.classList.add('active')
    }
  })
}

// Update effect picker UI
function updateEffectUI(effectId) {
  document.querySelectorAll('.effect-btn').forEach(btn => {
    btn.classList.remove('active')
    if (btn.dataset.effect === effectId) {
      btn.classList.add('active')
    }
  })
}

// Extension toggle handlers
document.querySelectorAll('.toggle-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const mode = btn.dataset.mode

    // Update storage
    const result = await chrome.storage.local.get(STORAGE_KEY)
    const library = result[STORAGE_KEY] || {
      version: '1.0',
      activeEffectId: 'blade-classic',
      effects: [],
      settings: { activeExtension: 'dual', globalOpacity: 0.9, disabledDomains: [] }
    }

    library.settings.activeExtension = mode
    await chrome.storage.local.set({ [STORAGE_KEY]: library })

    // Update UI
    updateToggleUI(mode)

    // Notify all tabs
    const tabs = await chrome.tabs.query({})
    for (const tab of tabs) {
      if (tab.id) {
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: 'ACTIVE_EXTENSION_CHANGED',
            active: mode
          })
        } catch {}
      }
    }

    // Notify Mage extension
    try {
      chrome.runtime.sendMessage('MAGE_EXTENSION_ID_PLACEHOLDER', {
        type: 'ACTIVE_EXTENSION_CHANGED',
        active: mode
      })
    } catch {}
  })
})

// Effect picker handlers
document.querySelectorAll('.effect-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const effectId = btn.dataset.effect

    // Update storage
    const result = await chrome.storage.local.get(STORAGE_KEY)
    const library = result[STORAGE_KEY] || {
      version: '1.0',
      activeEffectId: 'blade-classic',
      effects: [],
      settings: { activeExtension: 'dual', globalOpacity: 0.9, disabledDomains: [] }
    }

    library.activeEffectId = effectId
    await chrome.storage.local.set({ [STORAGE_KEY]: library })

    // Update UI
    updateEffectUI(effectId)

    // Notify all tabs
    const tabs = await chrome.tabs.query({})
    for (const tab of tabs) {
      if (tab.id) {
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: 'ACTIVE_EFFECT_CHANGED',
            effectId
          })
        } catch {}
      }
    }
  })
})

// Spell slot click handlers
document.querySelectorAll('.spell-slot').forEach((slot, index) => {
  slot.addEventListener('click', async () => {
    const spells = [
      { type: 'emoji', content: '🛡️', yangYin: 'yang' },
      { type: 'keyword', content: 'DO_NOT_TRACK', yangYin: 'yang' },
      { type: 'keyword', content: 'PRIVACY', yangYin: 'yang' },
      { type: 'emoji', content: '🐉', yangYin: 'yang' }
    ]

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'CAST_SPELL',
        spell: spells[index]
      })
    }
  })
})

// Disable on site button
document.getElementById('disable-btn').addEventListener('click', async () => {
  const result = await chrome.storage.local.get(STORAGE_KEY)
  const library = result[STORAGE_KEY] || {
    version: '1.0',
    activeEffectId: 'blade-classic',
    effects: [],
    settings: { activeExtension: 'dual', globalOpacity: 0.9, disabledDomains: [] }
  }

  const disabled = library.settings.disabledDomains || []
  const index = disabled.indexOf(currentDomain)

  if (index === -1) {
    disabled.push(currentDomain)
    document.getElementById('disable-btn').textContent = 'Enable on this site'
  } else {
    disabled.splice(index, 1)
    document.getElementById('disable-btn').textContent = 'Disable on this site'
  }

  library.settings.disabledDomains = disabled
  await chrome.storage.local.set({ [STORAGE_KEY]: library })

  // Notify current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: 'DOMAIN_TOGGLE',
      domain: currentDomain,
      disabled: index === -1
    })
  }
})

// Initialize
init()
