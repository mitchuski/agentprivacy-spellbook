
// Get current tab
chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
  const tab = tabs[0]
  if (!tab?.id) return

  // Get domain
  try {
    const url = new URL(tab.url)
    document.getElementById('domain').textContent = url.hostname
  } catch {}

  // Request state from background
  chrome.runtime.sendMessage({ type: 'REQUEST_STATE' }, (response) => {
    if (chrome.runtime.lastError) return

    if (response) {
      // Swordsman status
      if (response.swordDetected) {
        document.getElementById('sword-dot').style.opacity = '1'
        document.getElementById('sword-status').textContent = 'Connected'
        document.getElementById('sword-warning').style.display = 'none'
      } else {
        document.getElementById('sword-warning').style.display = 'block'
      }

      // Mana
      if (response.manaState?.mana_state) {
        document.getElementById('mana').textContent = response.manaState.mana_state.balance || 0
      }
    }
  })
})

// Hexagram display helper
function renderHexagram(lines) {
  // lines is [0|1, 0|1, 0|1, 0|1, 0|1, 0|1]
  // 1 = yang (solid), 0 = yin (broken)
  return lines.map(l => l === 1 ? '━━━' : '━ ━').join(' ')
}
