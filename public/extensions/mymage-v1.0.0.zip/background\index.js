// ../shared/types/index.ts
var SWORDSMAN_EXTENSION_ID = "SWORDSMAN_EXTENSION_ID_PLACEHOLDER";

// src/background/index.ts
var swordDetected = false;
var sharedSecret = null;
var grimoireLoaded = false;
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[Mage] Extension installed:", details.reason);
  if (details.reason === "install") {
    await initializeGrimoire();
    await initializeManaState();
  }
  startSwordDetection();
});
chrome.runtime.onStartup.addListener(async () => {
  console.log("[Mage] Extension started");
  await loadState();
  startSwordDetection();
});
async function initializeGrimoire() {
  const grimoireState = {
    spellbooks: ["story", "zk", "canon", "parallel", "plurality"],
    loaded: true,
    spellCount: 0
  };
  await chrome.storage.local.set({ grimoireState });
  grimoireLoaded = true;
  console.log("[Mage] Grimoire initialized");
}
async function loadState() {
  const data = await chrome.storage.local.get(["grimoireState", "manaState", "knowledgeGraph"]);
  grimoireLoaded = data.grimoireState?.loaded || false;
  console.log("[Mage] State loaded");
}
async function initializeManaState() {
  const defaultState = {
    balance: 0,
    totalEarned: 0,
    totalSpent: 0,
    history: [],
    lastSyncWithMageMode: 0
  };
  await chrome.storage.local.set({ manaState: defaultState });
  console.log("[Mage] Mana state initialized");
}
async function addMana(amount, type, domain, details) {
  const data = await chrome.storage.local.get("manaState");
  const state = data.manaState || { balance: 0, totalEarned: 0, totalSpent: 0, history: [], lastSyncWithMageMode: 0 };
  state.balance += amount;
  state.totalEarned += amount;
  state.history.push({
    type,
    amount,
    timestamp: Date.now(),
    domain,
    details
  });
  if (state.history.length > 100) {
    state.history = state.history.slice(-100);
  }
  await chrome.storage.local.set({ manaState: state });
  console.log(`[Mage] Mana earned: +${amount} (total: ${state.balance})`);
}
function startSwordDetection() {
  setInterval(async () => {
    try {
      await chrome.runtime.sendMessage(SWORDSMAN_EXTENSION_ID, { type: "PING" });
      if (!swordDetected) {
        console.log("[Mage] Swordsman extension detected!");
        swordDetected = true;
        await performKeyExchange();
      }
    } catch {
      if (swordDetected) {
        console.log("[Mage] Swordsman extension disconnected");
        swordDetected = false;
        sharedSecret = null;
      }
    }
  }, 5e3);
}
async function performKeyExchange() {
  const keyPair = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveKey"]
  );
  const publicKey = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
  const response = await chrome.runtime.sendMessage(SWORDSMAN_EXTENSION_ID, {
    type: "KEY_EXCHANGE",
    publicKey
  });
  if (response?.publicKey) {
    const swordPublicKey = await crypto.subtle.importKey(
      "jwk",
      response.publicKey,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      []
    );
    sharedSecret = await crypto.subtle.deriveKey(
      { name: "ECDH", public: swordPublicKey },
      keyPair.privateKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
    console.log("[Mage] Key exchange complete");
  }
}
async function sendToSword(message) {
  if (!swordDetected) {
    console.log("[Mage] Swordsman not detected, message not sent");
    return;
  }
  try {
    await chrome.runtime.sendMessage(SWORDSMAN_EXTENSION_ID, message);
  } catch (error) {
    console.error("[Mage] Failed to send to Swordsman:", error);
  }
}
chrome.runtime.onMessageExternal.addListener(
  (message, sender, sendResponse) => {
    if (sender.id !== SWORDSMAN_EXTENSION_ID) {
      console.warn("[Mage] Received message from unknown extension");
      return;
    }
    handleSwordMessage(message, sendResponse);
    return true;
  }
);
async function handleSwordMessage(message, sendResponse) {
  switch (message.type) {
    case "SWORD_PRESENT":
      console.log("[Mage] Swordsman presence confirmed on:", message.domain);
      swordDetected = true;
      sendResponse({
        type: "MAGE_ACKNOWLEDGE",
        orbPosition: { x: 100, y: 100 },
        // Default position
        spellbookState: await getAvailableSpells()
      });
      break;
    case "ORB_POSITION":
      notifyContentScript({ type: "SWORD_ORB_POSITION", x: message.x, y: message.y });
      sendResponse({ acknowledged: true });
      break;
    case "SLASH":
      console.log("[Mage] Swordsman slashed:", message.target);
      notifyContentScript({ type: "SLASH_EVENT", data: message });
      sendResponse({ acknowledged: true });
      break;
    case "WARD":
      console.log("[Mage] Swordsman set ward:", message.boundary);
      notifyContentScript({ type: "WARD_EVENT", data: message });
      sendResponse({ acknowledged: true });
      break;
    case "TERM_ASSERT":
      console.log("[Mage] MyTerms asserted on:", message.domain);
      notifyContentScript({ type: "CRYSTALLISE", data: message });
      await addMana(2, "earn_ceremony", message.domain, "convergence");
      sendResponse({ acknowledged: true });
      break;
    case "CEREMONY_BEGIN":
      console.log("[Mage] Ceremony initiated by Swordsman:", message.ceremonyType);
      notifyContentScript({ type: "CEREMONY_FROM_SWORD", data: message });
      sendResponse({ acknowledged: true });
      break;
    case "SUMMON_DRAKE":
      console.log("[Mage] Drake summon requested");
      notifyContentScript({ type: "DRAKE_SUMMON_REQUEST", conditions: message.conditions });
      sendResponse({ acknowledged: true });
      break;
    case "KEY_EXCHANGE":
      sendResponse({ acknowledged: true });
      break;
    default:
      console.log("[Mage] Unknown message type:", message.type);
      sendResponse({ error: "Unknown message type" });
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleContentMessage(message, sender.tab?.id, sendResponse);
  return true;
});
async function handleContentMessage(message, tabId, sendResponse) {
  switch (message.type) {
    case "DEEP_SCAN_COMPLETE":
      console.log("[Mage] Deep scan complete for:", message.data.domain);
      await storeIntelligence(message.data);
      sendResponse({ success: true });
      break;
    case "SEND_TO_SWORD":
      await sendToSword(message.payload);
      sendResponse({ sent: true });
      break;
    case "REQUEST_STATE":
      sendResponse({
        swordDetected,
        grimoireLoaded,
        manaState: await chrome.storage.local.get("manaState")
      });
      break;
    case "ADD_MANA":
      await addMana(message.amount, message.eventType, message.domain, message.details);
      sendResponse({ success: true });
      break;
    case "GET_GRIMOIRE_SPELLS":
      sendResponse(await getAvailableSpells());
      break;
    default:
      sendResponse({ error: "Unknown message type" });
  }
}
async function storeIntelligence(findings) {
  const data = await chrome.storage.local.get("knowledgeGraph");
  const graph = data.knowledgeGraph || { domains: {} };
  graph.domains[findings.domain] = {
    ...findings,
    lastScanned: Date.now()
  };
  await chrome.storage.local.set({ knowledgeGraph: graph });
  console.log("[Mage] Intelligence stored for:", findings.domain);
}
async function getAvailableSpells() {
  return ["emoji_shield", "proverb_trust", "keyword_dnt", "hexagram_1"];
}
async function notifyContentScript(message) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]?.id) {
    chrome.tabs.sendMessage(tabs[0].id, message);
  }
}
console.log("[Mage] Background service worker initialized");
//# sourceMappingURL=index.js.map
