"use strict";
(() => {
  // ../shared/types/index.ts
  var SWORDSMAN_EXTENSION_ID = "SWORDSMAN_EXTENSION_ID_PLACEHOLDER";

  // src/content/index.ts
  var swordPresent = false;
  var swordOrbPosition = { x: 0, y: 0 };
  var mageOrbState = {
    x: 100,
    y: 100,
    vx: 0,
    vy: 0,
    attractors: []
  };
  var constellationState = {
    nodes: [],
    edges: [],
    patterns: [],
    hash: null
  };
  var hexagramState = {
    lines: [1, 0, 1, 0, 1, 0]
    // Default: hexagram 21 (Biting Through)
  };
  var drakeState = {
    eligible: false,
    summoned: false,
    formationProgress: 0,
    bodyNodes: [],
    patrolPath: []
  };
  var isHomeTerritoryPage = false;
  var homeTerritoryType = null;
  async function initialize() {
    console.log("[Mage Content] Initializing...");
    checkHomeTerritory();
    const hasSword = await discoverSwordsman();
    if (!hasSword) {
      console.log("[Mage Content] Swordsman not detected. Read-only mode.");
      runReadOnlyMode();
    } else {
      console.log("[Mage Content] Swordsman detected. Full ceremony mode.");
      runFullCeremonyMode();
    }
  }
  async function discoverSwordsman() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(SWORDSMAN_EXTENSION_ID, {
          type: "MAGE_PRESENT",
          domain: location.hostname,
          spellbookState: [],
          // TODO: Get from background
          orbPosition: { x: mageOrbState.x, y: mageOrbState.y }
        }, (response) => {
          if (chrome.runtime.lastError || !response) {
            resolve(false);
            return;
          }
          if (response.type === "SWORD_ACKNOWLEDGE" || response.acknowledged) {
            swordPresent = true;
            swordOrbPosition = response.orbPosition || { x: 0, y: 0 };
            resolve(true);
          } else {
            resolve(false);
          }
        });
      } catch {
        resolve(false);
      }
    });
  }
  setInterval(async () => {
    if (!swordPresent) {
      const found = await discoverSwordsman();
      if (found) {
        runFullCeremonyMode();
      }
    }
  }, 3e4);
  var HOME_DOMAINS = [
    "agentprivacy.ai",
    "www.agentprivacy.ai",
    "spellweb.ai",
    "www.spellweb.ai",
    "bgin.ai",
    "www.bgin.ai",
    // Local development
    "localhost",
    "127.0.0.1"
  ];
  function checkHomeTerritory() {
    const host = location.hostname.replace("www.", "");
    const port = location.port;
    isHomeTerritoryPage = HOME_DOMAINS.includes(host);
    if ((host === "localhost" || host === "127.0.0.1") && port === "5000") {
      isHomeTerritoryPage = true;
    }
    if (isHomeTerritoryPage) {
      if (host === "agentprivacy.ai" || host === "localhost" || host === "127.0.0.1") {
        homeTerritoryType = "agentprivacy";
      } else if (host === "spellweb.ai") {
        homeTerritoryType = "spellweb";
      } else if (host === "bgin.ai") {
        homeTerritoryType = "bgin";
      }
      console.log("[Mage Content] Home territory detected:", homeTerritoryType);
    }
  }
  function runReadOnlyMode() {
    const scan = deepScanPage();
    chrome.runtime.sendMessage({ type: "DEEP_SCAN_COMPLETE", data: scan });
  }
  function runFullCeremonyMode() {
    setupMessageListeners();
    const scan = deepScanPage();
    sendScanToSword(scan);
    mageOrbState.attractors = buildAttractors(scan);
    startMageOrbPhysics();
    startConstellationSync();
    checkDrakeEligibility(scan);
    if (isHomeTerritoryPage) {
      activateHomeTerritoryMode();
    }
  }
  function deepScanPage() {
    const domain = location.hostname;
    const trackerCategories = {};
    const scripts = [...document.scripts].filter((s) => s.src);
    for (const script of scripts) {
      try {
        const host = new URL(script.src).hostname;
        if (host && host !== domain && !host.endsWith("." + domain)) {
          const category = categorizeTracker(host);
          if (!trackerCategories[category]) trackerCategories[category] = [];
          trackerCategories[category].push(host);
        }
      } catch {
      }
    }
    const privacyLink = document.querySelector('a[href*="privacy"]');
    const privacyPolicyAnalysis = {
      url: privacyLink?.href || null,
      score: privacyLink ? 0.5 : 0.3,
      // Basic heuristic
      keywords: {
        dataSharing: [],
        retention: [],
        thirdParty: [],
        userRights: []
      }
    };
    const darkPatterns = detectDarkPatterns();
    const forms = document.querySelectorAll("form");
    const sensitiveInputs = document.querySelectorAll(
      'input[type="email"], input[type="tel"], input[name*="ssn"], input[name*="social"], input[name*="password"]'
    );
    const hiddenInputs = document.querySelectorAll('input[type="hidden"]');
    const formAnalysis = {
      totalForms: forms.length,
      totalSensitiveFields: sensitiveInputs.length,
      hasHiddenInputs: hiddenInputs.length > 0
    };
    const metaTags = {
      hasDoNotTrack: !!document.querySelector('meta[name="dnt"]'),
      hasGPC: !!document.querySelector('meta[name="gpc"]'),
      opaqueTracking: []
    };
    let gapScore = 20;
    gapScore += Object.values(trackerCategories).flat().length * 5;
    gapScore += darkPatterns.preCheckedConsent * 10;
    gapScore += darkPatterns.hiddenReject ? 20 : 0;
    gapScore += formAnalysis.totalSensitiveFields * 3;
    gapScore = Math.min(100, Math.max(0, gapScore));
    return {
      domain,
      trackerCategories,
      privacyPolicyAnalysis,
      darkPatterns,
      formAnalysis,
      metaTags,
      gapScore
    };
  }
  function categorizeTracker(host) {
    const TRACKER_CATEGORIES = {
      "google-analytics.com": "analytics",
      "googletagmanager.com": "tag-management",
      "facebook.net": "social-tracking",
      "doubleclick.net": "advertising",
      "hotjar.com": "session-recording",
      "fullstory.com": "session-recording",
      "mixpanel.com": "analytics",
      "segment.com": "data-collection",
      "amplitude.com": "analytics"
    };
    for (const [pattern, category] of Object.entries(TRACKER_CATEGORIES)) {
      if (host.includes(pattern)) return category;
    }
    return "unknown";
  }
  function detectDarkPatterns() {
    const preChecked = document.querySelectorAll(
      'input[type="checkbox"]:checked[name*="consent"], input[type="checkbox"]:checked[name*="marketing"]'
    );
    const bannerSelectors = ["#onetrust-banner-sdk", ".cookieconsent", "#cookie-banner", '[class*="cookie"]', '[id*="consent"]'];
    const banner = bannerSelectors.map((s) => document.querySelector(s)).find(Boolean);
    let hiddenReject = false;
    if (banner) {
      const buttons = banner.querySelectorAll('button, a[role="button"]');
      const reject = [...buttons].find((b) => /reject|decline|refuse|deny|no\s|essential/i.test(b.textContent || ""));
      if (reject) {
        const style = getComputedStyle(reject);
        hiddenReject = style.opacity === "0" || style.visibility === "hidden" || style.display === "none" || reject.offsetWidth < 10;
      } else {
        hiddenReject = true;
      }
    }
    return {
      preCheckedConsent: preChecked.length,
      hiddenReject,
      confusingLanguage: false,
      // TODO: NLP analysis
      urgencyTactics: false
      // TODO: Pattern matching
    };
  }
  function sendScanToSword(scan) {
    const waveData = {
      type: "CONSTELLATION_WAVE",
      direction: "MAGE_TO_SWORD",
      payload: {
        threatLevel: scan.gapScore > 50 ? 0.7 : 0.3,
        suggestedAssertions: generateSpellSuggestions(scan),
        trackerCount: Object.values(scan.trackerCategories).flat().length,
        darkPatternCount: scan.darkPatterns.preCheckedConsent + (scan.darkPatterns.hiddenReject ? 1 : 0),
        gapScore: scan.gapScore
      },
      animation: {
        particleCount: Math.min(20, Object.values(scan.trackerCategories).flat().length),
        pathType: "geodesic",
        duration: 2e3
      }
    };
    sendToSword(waveData);
    if (isHomeTerritoryPage) {
      window.postMessage({
        type: "SCAN_RESULTS",
        findings: scan
      }, "*");
    }
  }
  function generateSpellSuggestions(scan) {
    const suggestions = [];
    if (Object.values(scan.trackerCategories).flat().length > 5) {
      suggestions.push("DO_NOT_TRACK");
    }
    if (scan.darkPatterns.preCheckedConsent > 0) {
      suggestions.push("COOKIE_ESSENTIAL_ONLY");
    }
    if (scan.formAnalysis.totalSensitiveFields > 0) {
      suggestions.push("DATA_MINIMISATION");
    }
    return suggestions;
  }
  function startMageOrbPhysics() {
    let lastTime = performance.now();
    function update() {
      const now = performance.now();
      const dt = (now - lastTime) / 1e3;
      lastTime = now;
      updateMageOrb(dt);
      maybeSendPosition();
      requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }
  function updateMageOrb(dt) {
    const baseVx = Math.sin(Date.now() * 7e-4) * 0.3;
    const baseVy = Math.cos(Date.now() * 5e-4) * 0.2;
    let ax = baseVx, ay = baseVy;
    for (const att of mageOrbState.attractors) {
      const dx = att.x - mageOrbState.x;
      const dy = att.y - mageOrbState.y;
      const dist = Math.sqrt(dx * dx + dy * dy) + 1;
      const force = att.strength / (dist * dist) * 100;
      ax += dx / dist * force;
      ay += dy / dist * force;
    }
    mageOrbState.vx = (mageOrbState.vx + ax * dt) * 0.95;
    mageOrbState.vy = (mageOrbState.vy + ay * dt) * 0.95;
    mageOrbState.x += mageOrbState.vx;
    mageOrbState.y += mageOrbState.vy;
    mageOrbState.x = Math.max(20, Math.min(window.innerWidth - 20, mageOrbState.x));
    mageOrbState.y = Math.max(20, Math.min(window.innerHeight - 20, mageOrbState.y));
  }
  function buildAttractors(scan) {
    const attractors = [];
    const banner = document.querySelector('#onetrust-banner-sdk, [class*="cookie"], [id*="consent"]');
    if (banner) {
      const rect = banner.getBoundingClientRect();
      attractors.push({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
        strength: 0.5,
        type: "cookie-banner"
      });
    }
    document.querySelectorAll("form").forEach((form) => {
      const rect = form.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        attractors.push({
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          strength: 0.2,
          type: "form"
        });
      }
    });
    const privacyLink = document.querySelector('a[href*="privacy"]');
    if (privacyLink) {
      const rect = privacyLink.getBoundingClientRect();
      attractors.push({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
        strength: 0.3,
        type: "privacy-link"
      });
    }
    return attractors;
  }
  var lastPositionSend = 0;
  function maybeSendPosition() {
    const now = performance.now();
    if (now - lastPositionSend < 33) return;
    lastPositionSend = now;
    sendToSword({
      type: "MAGE_ORB_POSITION",
      x: mageOrbState.x,
      y: mageOrbState.y
    });
  }
  function startConstellationSync() {
    setInterval(() => {
      if (swordPresent && constellationState.nodes.length > 0) {
        sendConstellationToSword();
      }
    }, 100);
  }
  function updateConstellation() {
    constellationState.edges = [];
    for (let i = 0; i < constellationState.nodes.length; i++) {
      for (let j = i + 1; j < constellationState.nodes.length; j++) {
        const dx = constellationState.nodes[i].x - constellationState.nodes[j].x;
        const dy = constellationState.nodes[i].y - constellationState.nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 180) {
          const sameType = constellationState.nodes[i].spell.yangYin === constellationState.nodes[j].spell.yangYin;
          constellationState.edges.push({
            from: constellationState.nodes[i].id,
            to: constellationState.nodes[j].id,
            strength: 1 - dist / 180,
            type: sameType ? "solid" : "dashed"
          });
        }
      }
    }
    constellationState.patterns = detectPatterns();
    constellationState.hash = computeConstellationHash();
  }
  function detectPatterns() {
    const patterns = [];
    if (constellationState.edges.length >= 1) {
      for (const edge of constellationState.edges) {
        patterns.push({ type: "pair", nodeIds: [edge.from, edge.to] });
      }
    }
    for (let i = 0; i < constellationState.nodes.length; i++) {
      for (let j = i + 1; j < constellationState.nodes.length; j++) {
        for (let k = j + 1; k < constellationState.nodes.length; k++) {
          const hasIJ = constellationState.edges.some(
            (e) => e.from === constellationState.nodes[i].id && e.to === constellationState.nodes[j].id || e.from === constellationState.nodes[j].id && e.to === constellationState.nodes[i].id
          );
          const hasJK = constellationState.edges.some(
            (e) => e.from === constellationState.nodes[j].id && e.to === constellationState.nodes[k].id || e.from === constellationState.nodes[k].id && e.to === constellationState.nodes[j].id
          );
          const hasIK = constellationState.edges.some(
            (e) => e.from === constellationState.nodes[i].id && e.to === constellationState.nodes[k].id || e.from === constellationState.nodes[k].id && e.to === constellationState.nodes[i].id
          );
          if (hasIJ && hasJK && hasIK) {
            patterns.push({
              type: "triangle",
              nodeIds: [constellationState.nodes[i].id, constellationState.nodes[j].id, constellationState.nodes[k].id]
            });
          }
        }
      }
    }
    return patterns;
  }
  function computeConstellationHash() {
    const normalized = constellationState.nodes.map((n) => ({
      x: Math.round(n.x / 10),
      y: Math.round(n.y / 10),
      yin: n.spell.yangYin === "yin"
    }));
    return btoa(JSON.stringify(normalized)).slice(0, 32);
  }
  function sendConstellationToSword() {
    const constellationData = {
      type: "CONSTELLATION_UPDATE",
      nodes: constellationState.nodes.map((n) => ({
        id: n.id,
        x: n.x,
        y: n.y,
        yangYin: n.spell.yangYin,
        opacity: n.opacity,
        pulse: n.pulse,
        emoji: n.spell.type === "emoji" ? n.spell.content : void 0
      })),
      edges: constellationState.edges,
      patterns: constellationState.patterns
    };
    sendToSword(constellationData);
    if (isHomeTerritoryPage) {
      window.postMessage(constellationData, "*");
    }
  }
  function addSpellNode(spell, position) {
    const node = {
      id: crypto.randomUUID(),
      spell,
      x: position.x,
      y: position.y,
      opacity: 1,
      pulse: 0,
      castAt: Date.now()
    };
    constellationState.nodes.push(node);
    updateConstellation();
    chrome.runtime.sendMessage({
      type: "ADD_MANA",
      amount: 0.1,
      eventType: "earn_spell",
      domain: location.hostname,
      details: spell.content
    });
  }
  function checkDrakeEligibility(scan) {
    const trackerCount = Object.values(scan.trackerCategories).flat().length;
    const darkPatternCount = scan.darkPatterns.preCheckedConsent + (scan.darkPatterns.hiddenReject ? 1 : 0);
    drakeState.eligible = trackerCount >= 10 || darkPatternCount >= 1 || scan.privacyPolicyAnalysis.score < 0.3 || location.hostname.includes("agentprivacy.ai");
    if (drakeState.eligible) {
      console.log("[Mage Content] Drake eligible on this page");
    }
  }
  function initiateDrakeFormation() {
    if (!drakeState.eligible || constellationState.nodes.length < 7) {
      console.log("[Mage Content] Drake formation requirements not met");
      return;
    }
    drakeState.summoned = true;
    drakeState.formationProgress = 0;
    drakeState.bodyNodes = computeDrakeBodyNodes();
    drakeState.patrolPath = computePatrolPath();
    const animate = () => {
      drakeState.formationProgress += 0.02;
      if (drakeState.formationProgress < 1) {
        requestAnimationFrame(animate);
      }
      sendDrakeToSword();
    };
    requestAnimationFrame(animate);
  }
  function computeDrakeBodyNodes() {
    const pvmConditions = ["P", "C", "Q", "S", "network", "phi", "R"];
    const cx = constellationState.nodes.reduce((s, n) => s + n.x, 0) / constellationState.nodes.length;
    const cy = constellationState.nodes.reduce((s, n) => s + n.y, 0) / constellationState.nodes.length;
    const sorted = [...constellationState.nodes].sort((a, b) => {
      const angleA = Math.atan2(a.y - cy, a.x - cx);
      const angleB = Math.atan2(b.y - cy, b.x - cx);
      return angleA - angleB;
    });
    return sorted.slice(0, 7).map((node, i) => ({
      nodeId: node.id,
      pvmCondition: pvmConditions[i],
      position: { x: node.x, y: node.y },
      health: 1
    }));
  }
  function computePatrolPath() {
    const cx = constellationState.nodes.reduce((s, n) => s + n.x, 0) / constellationState.nodes.length;
    const cy = constellationState.nodes.reduce((s, n) => s + n.y, 0) / constellationState.nodes.length;
    const radius = 150;
    const path = [];
    for (let i = 0; i < 8; i++) {
      const angle = i / 8 * Math.PI * 2;
      path.push({
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius
      });
    }
    return path;
  }
  function sendDrakeToSword() {
    if (!drakeState.summoned) return;
    sendToSword({
      type: "DRAKE_FORMATION",
      bodyNodes: drakeState.bodyNodes,
      patrolPath: drakeState.patrolPath,
      formationProgress: drakeState.formationProgress
    });
  }
  function mutateHexagram(trigger) {
    const lineIndex = trigger === "scroll" ? Math.floor(window.scrollY / document.body.scrollHeight * 6) % 6 : trigger === "spell" ? constellationState.nodes.length % 6 : Math.floor(Math.random() * 6);
    hexagramState.lines[lineIndex] = hexagramState.lines[lineIndex] === 1 ? 0 : 1;
    hexagramState.number = hexagramState.lines.reduce((acc, line, i) => acc + line * Math.pow(2, 5 - i), 0) + 1;
    sendHexagramUpdate();
  }
  function hexagramToAnimationParams() {
    return {
      orbitRadii: hexagramState.lines[0] ? 0.7 : 1,
      spellSpawnRate: hexagramState.lines[1] ? 0.8 : 0.3,
      phaseCoupling: hexagramState.lines[2] ? 0.8 : 0.2,
      edgeThreshold: hexagramState.lines[3] ? 120 : 220,
      glowIntensity: hexagramState.lines[4] ? 0.4 : 0.15,
      gridVisibility: hexagramState.lines[5] ? 0.08 : 0.02
    };
  }
  function sendHexagramUpdate() {
    sendToSword({
      type: "HEXAGRAM_UPDATE",
      state: hexagramState,
      animationParams: hexagramToAnimationParams()
    });
  }
  var lastScrollY = 0;
  window.addEventListener("scroll", () => {
    const scrollDelta = Math.abs(window.scrollY - lastScrollY);
    if (scrollDelta > 500) {
      mutateHexagram("scroll");
      lastScrollY = window.scrollY;
    }
  }, { passive: true });
  function activateHomeTerritoryMode() {
    console.log("[Mage Content] Activating home territory mode:", homeTerritoryType);
    window.addEventListener("message", handleWebsiteMessage);
    announceToWebsite();
    setInterval(announceToWebsite, 5e3);
  }
  function announceToWebsite() {
    window.postMessage({
      type: "MAGE_PRESENT",
      domain: location.hostname,
      orbPosition: { x: mageOrbState.x, y: mageOrbState.y },
      homeTerritoryType,
      capabilities: ["deep-scan", "constellation", "hexagram", "drake"]
    }, "*");
  }
  function handleWebsiteMessage(event) {
    if (event.origin !== location.origin) return;
    const { data } = event;
    if (!data || !data.type) return;
    switch (data.type) {
      case "WEBSITE_READY":
        console.log("[Mage Content] Website ready, capabilities:", data.capabilities);
        announceToWebsite();
        break;
      case "CEREMONY_CONFIRMATION":
        console.log("[Mage Content] Inscription confirmed:", data.action);
        break;
      case "CEREMONY_ERROR":
        console.warn("[Mage Content] Inscription error:", data.reason);
        break;
      case "PROVERB_INSCRIBED":
        console.log("[Mage Content] Proverb inscribed:", data.proverbId);
        chrome.runtime.sendMessage({
          type: "ADD_MANA",
          amount: 1,
          eventType: "proverb_inscribed",
          domain: location.hostname,
          details: data.tale
        });
        break;
      case "MANA_EARNED":
        chrome.runtime.sendMessage({
          type: "ADD_MANA",
          amount: data.amount,
          eventType: "website_earn",
          domain: location.hostname,
          details: data.reason
        });
        break;
      case "MANA_SPENT":
        chrome.runtime.sendMessage({
          type: "SPEND_MANA",
          amount: data.amount,
          eventType: "website_spend",
          domain: location.hostname,
          details: data.reason
        });
        break;
      case "SPELLBOOK_UNLOCKED":
        console.log("[Mage Content] Spellbook unlocked:", data.grimoire);
        chrome.runtime.sendMessage({
          type: "GRIMOIRE_UNLOCKED",
          grimoire: data.grimoire
        });
        break;
    }
  }
  function setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      switch (message.type) {
        case "SWORD_ORB_POSITION":
          swordOrbPosition = { x: message.x, y: message.y };
          break;
        case "SLASH_EVENT":
          addSpellNode({
            type: "keyword",
            content: message.data.assertion,
            yangYin: "yang"
          }, { x: mageOrbState.x, y: mageOrbState.y });
          break;
        case "WARD_EVENT":
          mutateHexagram("spell");
          break;
        case "CRYSTALLISE":
          console.log("[Mage Content] Constellation crystallised");
          break;
        case "DRAKE_SUMMON_REQUEST":
          initiateDrakeFormation();
          break;
      }
      sendResponse({ received: true });
    });
    chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
      if (sender.id !== SWORDSMAN_EXTENSION_ID) return;
      switch (message.type) {
        case "SWORD_PRESENT":
          swordPresent = true;
          swordOrbPosition = message.orbPosition || { x: 0, y: 0 };
          sendResponse({
            type: "MAGE_ACKNOWLEDGE",
            orbPosition: { x: mageOrbState.x, y: mageOrbState.y },
            spellbookState: []
          });
          if (!swordPresent) {
            runFullCeremonyMode();
          }
          break;
        case "ORB_POSITION":
          swordOrbPosition = { x: message.x, y: message.y };
          sendResponse({ acknowledged: true });
          break;
      }
    });
  }
  function sendToSword(message) {
    if (!swordPresent) return;
    try {
      chrome.runtime.sendMessage(SWORDSMAN_EXTENSION_ID, message);
    } catch (error) {
      console.error("[Mage Content] Failed to send to Swordsman:", error);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }
  console.log("[Mage Content] Script loaded");
})();
//# sourceMappingURL=index.js.map
